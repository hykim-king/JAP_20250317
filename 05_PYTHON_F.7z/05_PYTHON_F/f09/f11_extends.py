#부모 클래스
class Animal:
    '''
    클래스
    '''

    def speak(self):
        print('동물이 소리를 냅니다.')

#자식 클래스 정의(Animal 상속)
class Dog(Animal):
    def bark(self):
        print('멍멈')


def main():
    #객체 생성 및 사용
    dog = Dog()

    dog.speak()#부모 클래스 메서드 호출
    dog.bark()# 자식 클래스 메서드 호출


if __name__ == '__main__':
    main()
