import csv

#CSV저장



def read_csv(filename):
    '''
    CSV읽기
    :param filename:
    :return: void
    '''
    with open('csv_data.csv', 'r', encoding='utf-8') as file:
        reader = csv.reader(file)
        # print(f'reader:{type(reader)}')
        for row in reader:
            print(row)

def write_csv(filename,data):
    '''
    csv파일 생성
    :param filename:
    :param data:
    :return: void
    '''

    #newline='' : \n을 -> ''
    with open(filename,'w',newline='',encoding='utf-8') as file:
        writer=csv.writer(file)

        #header
        writer.writerow(['이름','나이','취미'])
        #data
        writer.writerows(data)
    print(f'filename:{filename} 파일이 생성 되었습니다.')

def main():
    """
    csv.reader 객체를 사용하여 csv파일을 한 줄씩 읽어 드립니다.
    """
    filename = 'csv_data.csv'
    read_csv(filename=filename)


    #
    data =[
        ['이상무', '22', '독서'],
        ['영희', '18', 'Cycling'],
        ['철수', '21', '게임']
    ]

    write_csv('pcwk.csv',data)

if __name__ == '__main__':
    main()
