import csv

def read_csv(filename):
    '''
    CSV읽기
    :param filename:
    :return: void
    '''

    with open(filename, 'r', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        # print(f'reader:{type(reader)}')
        for row in reader:
            name = row['이름']
            #print(f'name:{name}')
            scores =[int(row['국어']) + int(row['영어']) + int(row['수학']) ]
            avg = sum(scores)/len(scores)
            print(f'{name} 평균은:{avg}')





def main():
    """
    score.csv 파일에서 학생의 평균 점수를 계산하시오.
    홍길동,90,85,82
    김영희,95,92,88
    이철수,78,80,75

    """
    filename = 'score.csv'
    read_csv(filename)



if __name__ == '__main__':
    main()
