class Animal:

    def speak(self):
        print('동물이 소리를 냅니다.')

class Dog(Animal):
    def speak(self):
        super().speak() #부모 메서드 호출
        print('멍멍')


def main():
    dog=Dog()
    dog.speak()


if __name__ == '__main__':
    main()
