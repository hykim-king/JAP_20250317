def main():
    """
    
    """
    try:
        num=int(input('숫자를 입력 하세요>'))
        print(f'1')
        result = 10/num
        print(f'2')
    except ZeroDivisionError as e:
         print(f'ZeroDivisionError: e:{e}')
    except ValueError as e:
         print(f'ValueError:(숫자만 입력 하세요.) e:{e}')
    except  Exception as e:
        print(f'Exception, e:{e}')




if __name__ == '__main__':
    main()
