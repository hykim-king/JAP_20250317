def main():
    """
    
    """

    try:
        result = 10/ 0
    except ZeroDivisionError as e:
        print(f'0으로 나눌수 없습니다.\n e:{e}')




if __name__ == '__main__':
    main()
