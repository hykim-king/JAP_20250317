import csv


def read_csv(filename):
    '''
    CSV읽기
    :param filename:
    :return: void
    '''
    with open(filename, 'r', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        # print(f'reader:{type(reader)}')
        for row in reader:
            name=row['이름']
            tmp_list = [int(row['국어']),int(row['영어']),int(row['수학'])]
            avg=sum(tmp_list)/len(tmp_list)
            print(f'{name}의 평균은 {avg:.2f} 입니다.')





def main():
    """
    
    """
    read_csv('score.csv')




if __name__ == '__main__':
    main()
