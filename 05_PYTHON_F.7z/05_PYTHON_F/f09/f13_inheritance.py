class Walkable:
    def walk(selfs):
        print('걷는다.')


class Runnable:
    def run(self):
        print('뛴다.')


class Human(Walkable,Runnable):
    pass


h=Human()
h.walk()
h.run()