class Dog:
    #클래스 속성
    shared_value = 14


    def __init__(self,name,age):
        '''
        생성자
        :param name:
        :param age:
        '''
        #속성(인스턴스 속성)
        self.name = name
        self.age  = age

    def bark(self):
        print(f'{self.name}가 짖습니다.')

    def info(self):
        print(f'{self.name}는 {self.age}살 입니다.')



def main():
    """
    
    """
    dog1= Dog('멍멍이',2)
    print(f'dog1:{dog1},type:{type(dog1)}')
    dog1.bark()
    dog1.info()

    dog2=Dog('바둑이',3)
    dog2.info()

    #클래스 속성 호출
    print(f'Dog.shared_value:{Dog.shared_value}')
    print(f'dog1.shared_value:{dog1.shared_value}')
    print(f'dog2.shared_value:{dog2.shared_value}')
    Dog.shared_value = 16 # 공유변수 값변경
    print(f'dog1.shared_value:{dog1.shared_value}')
    print(f'dog2.shared_value:{dog2.shared_value}')

if __name__ == '__main__':
    main()
