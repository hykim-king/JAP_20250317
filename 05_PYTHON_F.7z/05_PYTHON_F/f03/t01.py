def main():
    """
    
    """
print(f'왼쪽 정렬: \'{"Hello":<10}\'')   # Hello
print(f"가운데 정렬: \'{'Hello':^10}\'") #   Hello
print(f"오른쪽 정렬: \'{'Hello':>10}\'") #      Hello


if __name__ == '__main__':
    main()
