def main():
    """
    사용자 입력 받은 값 숫자로 변경
    """

    user_input=input("숫자를 입력하세요:") #str로 return
    print(user_input,type(user_input))
    num = int(user_input)

    print(num+10)

    ########################################
    data = [1,2,2,3,3,3]

    unique = list(set(data))
    print(unique,type(unique))


if __name__ == '__main__':
    main()
