def main():
    """
    
    """

    name = '이상무'
    age  = 22
    height =178.8

    print("이름:%s"%name)
    print("나이:%d" % age)
    print("키:%.1f" % height)

    print("이름:%s, 나이:%d, 키:%.1f"%(name,age,height))
    ######################################
    name = '이상무'
    age = 22
    print(f"이름은 {name}이고, 나이는 {age}살 입니다.")
    print(f"이름은 {name}이고, 나이는 {age-1}살 입니다.")

    ######################################
    name = '이상무'
    age = 22

    print("이름은 {}이고, 나이는 {}살 입니다.".format(name, age))
    print("이름은 {1}이고, 나이는 {0}살 입니다.".format(name, age))
if __name__ == '__main__':
    main()
