def main():
    """
    시퀀스 자료형 변환
    """
    # 리스트 -> 튜플, 집합
    list_a = [1,2,2,3]
    print(list_a,type(list_a))

    tuple_a=tuple(list_a)
    print(tuple_a, type(tuple_a))

    set_a = set(list_a)
    print(set_a,type(set_a))

    ###############################
    tuple_b = (4,5,6)
    lst = list(tuple_b)
    print(lst,type(lst))


if __name__ == '__main__':
    main()
