def main():
    """
    
    """
    #숫자 ↔ 문자열
    num = 123
    print(num,type(num)) #123 <class 'int'>

    str_num=str(num)
    print(str_num,type(str_num)) #123 <class 'str'>

    back_to_num = int(str_num)
    print(back_to_num, type(back_to_num)) #123 <class 'int'>
    ##############################################
    x = 10
    f = float(x) #10.0 <class 'float'>
    print(f, type(f))
    y = 3.14
    i = int(y)
    print(i, type(i)) #3 <class 'int'>

    ##############################################
    s = "3.14"
    f = float(s) #3.14 <class 'float'>
    print(f, type(f))

    s2= "100"
    i = int(s2)
    print(i, type(i))

    int("a")


if __name__ == '__main__':
    main()
