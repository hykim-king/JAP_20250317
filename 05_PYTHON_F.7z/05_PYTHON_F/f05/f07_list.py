def main():
    """
    ### 리스트(List)

    - 정의 : 순서가 있고, 변경 가능하며, 중복을 허용하는 컬렉션
    - 기호: [ ] 대괄호 사용
    """
    fruits = ['사과','바나나','체리',14]
    print(f' fruits[1]:{fruits[1]}')

    fruits[1] ='orange'
    print(f' fruits:{fruits}')


if __name__ == '__main__':
    main()
