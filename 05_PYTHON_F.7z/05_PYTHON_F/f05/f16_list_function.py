def main():
    """
    메서드	설명
    append(x)	리스트 끝에 요소 추가
    extend(iterable)	리스트에 다른 리스트나 iterable 요소 추가
    insert(i, x)	특정 위치 i에 요소 삽입
    remove(x)	첫 번째로 등장하는 요소 x 삭제
    pop([i])	특정 위치 i의 요소를 제거하고 반환 (기본: 마지막)
    index(x)	요소 x의 첫 번째 인덱스 반환
    count(x)	요소 x의 개수 반환
    sort()	리스트를 오름차순으로 정렬
    reverse()	리스트를 역순으로 정렬
    clear()	모든 요소 제거
    """

    #리스트
    numbers = [1,2,3,4,5,6,7,2]

    #CRUD
    #전체 출력
    print(f'전체 출력:{numbers}')

    #추가
    numbers.append(88)
    print(f'전체 출력:{numbers}')

    #변경
    numbers[0] = 99
    print(f'전체 출력:{numbers}')

    #삭제
    numbers.remove(2)
    print(f'전체 출력:{numbers}')

    # 삭제
    del numbers[-1]
    print(f'전체 출력:{numbers}')

    #리스트 끝요소 끄집어 내기
    print(f'리스트 끝요소 끄집어 내기:{numbers.pop()}')

    #리스트 sort :ASC
    print(f'sort:{numbers.sort()}')
    print(f'전체 출력:{numbers}')

    # 리스트 sort :DESC
    print(f'reverse:{numbers.reverse()}')
    print(f'전체 출력:{numbers}')


    #리스트 확장
    x = [1,2,3]
    x.extend([4,5])

    print(f'x:{x}') #x:[1, 2, 3, 4, 5]




if __name__ == '__main__':
    main()
