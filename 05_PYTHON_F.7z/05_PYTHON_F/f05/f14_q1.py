def main():
    """
     [10, 20, 30, 40, 50, 60, 70, 80]에서 마지막 4개의 요소를 거꾸로 추출하세요.
    """
    numbers_list= [10, 20, 30, 40, 50, 60, 70, 80]

    print(f'numbers_list[:-5:-1]:{numbers_list[:-5:-1]}')

    #####################################################
    data_list = [1, 3, 5, 7, 2, 4, 6, 8]

    even_index = data_list[::2]
    odd_index  = data_list[1::2]

    print(f'even_index:{even_index}')
    print(f'odd_index:{odd_index}')




if __name__ == '__main__':
    main()
