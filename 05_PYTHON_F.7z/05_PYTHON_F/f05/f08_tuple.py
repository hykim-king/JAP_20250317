def main():
    """
    ### 튜플(Tuple)

    - 정의 : 순서가 있고, **변경 불가능**, 중복을 허용하는 컬렉션
    - 기호 : ( ) 소괄호
    """
    colors = ('Red','Green',"Blue")
    print(f'colors[1]:{colors[1]}')

    #TypeError: 'tuple' object does not support item assignment
    colors[1] ='Black'

if __name__ == '__main__':
    main()
