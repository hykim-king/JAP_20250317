def main():
    """
    
    """
    mixed_list = [18,16,14,['A','B','C']]
    #['A','B','C']
    print(f'mixed_list[-1]:{mixed_list[-1]}')

    #'B'
    print(f'mixed_list[-1][1]:{mixed_list[-1][1]}')


    triple_list = [ 1,2,['A','B',['Life','Good']] ]
    #Life
    print(f'triple_list[-1][-1][0]:{triple_list[-1][-1][0]}')

if __name__ == '__main__':
    main()
