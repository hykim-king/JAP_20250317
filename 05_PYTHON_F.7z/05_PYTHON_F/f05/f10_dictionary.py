def main():
    """
    ### 딕셔너리(Dictionary)

- 정의 : 키와 값의 쌍으로 구성된 컬렉션, 순서가 있고, 키는 중복 불가
- 기호 : {key:value} 형태
    """

    student = {'name': '이상무', 'age': 22}

    print(student['name']) #이상무
    student['age'] = 21
    print(student) #{'name': '이상무', 'age': 21}

if __name__ == '__main__':
    main()
