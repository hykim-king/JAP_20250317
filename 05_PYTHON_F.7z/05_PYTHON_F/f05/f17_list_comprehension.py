def main():
    """
    
    """
    # 1~5까지 각각의 숫자를 제곱한 리스트 생성

    # for x in range(1,6):
    #     print(x**2)

    squares=[x**2 for x in range(1, 6)]
    print(f'squares:{squares}')

    #1~10중 짝수만 리스트로 생성
    evens=[x for x in range(1,11) if x % 2 == 0]
    print(f'evens:{evens}')


if __name__ == '__main__':
    main()
