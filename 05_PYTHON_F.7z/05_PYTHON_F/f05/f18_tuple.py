def get_min_max(numbers):
    return min(numbers),max(numbers)

def main():
    """
    
    """



    single_element=(5,)
    #single_element:(5,), type:<class 'tuple'>
    print(f'single_element:{single_element}, type:{type(single_element)}')

    not_a_tuple = (5)
    #not_a_tuple:5,type:<class 'int'>
    print(f'not_a_tuple:{not_a_tuple},type:{type(not_a_tuple)}')

    ##########################################
    print("#"*53)

    fruits= ('사과','바나나','체리')
    print(fruits[0])
    print(fruits[-1])

    ##########################################
    print("#"*53)

    numbers = (0,1,2,2,3,4,5,6,7)

    #1,2,3
    print(f'numbers[1:4]:{numbers[1:4]}')

    #역순으로 출력:(7, 6, 5, 4, 3, 2, 1, 0)
    print(f'numbers[::-1]:{numbers[::-1]}')

    ##########################################
    print("#"*53)

    print(f'numbers.count(2):{numbers.count(2)}')

    print(f'numbers.index(2):{numbers.index(3)}')

    print(f'{get_min_max(numbers)}')

if __name__ == '__main__':
    main()
