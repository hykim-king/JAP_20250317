def main():
    """
    
    """
    num_low= [1,2,3]
    num_hi =[4,5,6]

    print(f'num_low:{num_low}')
    print(f'num_hi:{num_hi}')
    print(f'num_low+num_hi:{num_low+num_hi}')

    ###########################################
    print("#"*53)
    #리스트 반복
    #num_low*3:[1, 2, 3, 1, 2, 3, 1, 2, 3]
    print(f'num_low*3:{num_low*3}')

if __name__ == '__main__':
    main()
