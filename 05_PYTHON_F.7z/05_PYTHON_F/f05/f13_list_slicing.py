def main():
    """
    
    """

    numbers = [10,20,30,40,50,60]
    print(f'numbers[1:4]:{numbers[1:4]}') #20,30,40

    #30,40,50,60
    #끝 인덱스 생략 : 끝까지 출력
    print(f'numbers[2:]:{numbers[2:]}')

    #10,20,30,40
    # 시작 인덱스 생략 : 0번지 부터
    print(f'numbers[:4]:{numbers[:4]}')

    #10 30 50
    print(f'numbers[::2]:{numbers[::2]}')

    # 역순 출력 : 60, 50, 40, 30, 20, 10
    print(f'numbers[::-1]:{numbers[::-1]}')


if __name__ == '__main__':
    main()
