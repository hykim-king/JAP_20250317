def main():
    """
연산자	의미	예시	결과
in	포함되어 있는가?	'a' in 'apple'	True
not in	포함되어 있지 않은가?	'b' not in 'apple'	True
    """

    print('a' in 'apple')     #True
    print('b' not in 'apple') #True


if __name__ == '__main__':
    main()
