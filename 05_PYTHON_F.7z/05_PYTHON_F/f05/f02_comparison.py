def main():
    """
    연산자	설명	예제	결과
    ==	같음	5 == 3	False
    !=	다름	5 != 3	True
    >	큼	5 > 3	True
    <	작음	5 < 3	False
    >=	크거나 같음	5 >= 5	True
    <=	작거나 같음	5 <= 3	False
    """

    print(f'5 == 3 :{5 == 3}') #5 == 3 :False
    print(f'5 != 3 :{5 != 3}') #5 != 3 :True

    print(f'5 <= 3 :{5 <= 3}') #5 <= 3 :False


if __name__ == '__main__':
    main()
