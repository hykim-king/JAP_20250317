def main():
    """
    연산자	의미	예시 (a = 5, b = 3)	결과
    &	AND	a & b	1
    |	OR	a | b	1
    ^	XOR	a ^ b	6
    ~	NOT	~a	-6
    <<	왼쪽 시프트	a << 1	10
    >>	오른쪽 시프트	a >> 1	2
    """
    a = 5
    b = 3
    print(a & b)
    print(a >> 1)



if __name__ == '__main__':
    main()
