def main():
    """
    
    """
    empty_list = []
    numbers_list = [1,2,3,3,4,5]
    string_list = ['banana','water melon','apple']
    mixed_list = [1,'hello',3.14,True]

    list_inner = [1, 2, 3, ['A','B','C']]

    print("*"*53)
    print(f'empty_list:{empty_list}')
    print(f'numbers_list:{numbers_list}')
    print(f'string_list:{string_list}')
    print(f'mixed_list:{mixed_list}')
    print("*"*53)
    ###################################################
    print(f'list_inner:{list_inner}')


if __name__ == '__main__':
    main()
