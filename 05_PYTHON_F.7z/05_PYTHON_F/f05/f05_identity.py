def main():
    """
    연산자	의미	예시	결과
is	동일한 객체인가?	a is b	False
is not	동일한 객체가 아닌가?	a is not b	True
    """
    a = 14
    b = 16

    print(f'a is b :{a is b}') #False
    print(f'a is not b :{a is not b}')  # True

if __name__ == '__main__':
    main()
