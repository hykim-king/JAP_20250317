from openai import OpenAI

api_key='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'


client = OpenAI(api_key=api_key)
print(f'client:{client}')


response = client.chat.completions.create(
    model="gpt-4o",
    temperature=0.1,
    messages=[
        {"role": "user", "content": "안녕, 너 뭐할 수 있어?"}
    ]
)
print(response.choices[0].message.content)