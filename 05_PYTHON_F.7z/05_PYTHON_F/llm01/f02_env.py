
# .env 파일에서 환경변수를 불러오기 위한 모듈
from dotenv import load_dotenv
import os

# OpenAI API 클라이언트
from openai import OpenAI


def hello_openAI():
    # 상위 폴더에 있는 .env 파일 로드
    load_dotenv(dotenv_path="../.env")

    # 환경변수에서 API 키 가져오기
    api_key  = os.getenv("OPENAI_API_KEY")

    # API 키가 없으면 에러 발생
    if not api_key:
        raise ValueError("OPENAI_API_KEY가 설정되지 않았습니다.")

    # OpenAI 클라이언트 객체 생성
    client = OpenAI(api_key=api_key)

    # GPT-4o 모델에 메시지를 보내고 응답 받기
    response = client.chat.completions.create(
        model="gpt-4o",         # 최신 고성능 모델
        temperature=0.1,        # 낮은 창의성 (정확한 답변 유도)
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},  # 시스템 지시
            {"role": "user", "content": "2022년 월드컵 우승팀은 어디야?"},  # 사용자 질문
        ]
    )

    # 응답 출력
    print('*' * 80)
    print(f'response: {response.choices[0].message.content}')
    print('*' * 80)





def main():
    hello_openAI()




if __name__ == '__main__':
    main()
