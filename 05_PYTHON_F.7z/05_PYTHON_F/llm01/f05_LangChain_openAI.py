from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv


def lang_chain():
    # 1. API 키 불러오기
    load_dotenv(dotenv_path="../.env")

    # 1. 프롬프트 템플릿
    prompt = PromptTemplate.from_template( template="다음 글에 대한 피드백을 교사처럼 해줘:\n\n{essay}")

    # 2. LLM 설정
    llm = ChatOpenAI(model="gpt-4o", temperature=0)

    # 3. 파이프라인 실행 (prompt | llm)
    chain = prompt | llm  # ⬅️ 최신 구조

    # 4. 실행
    response = chain.invoke({"essay": ""})  # ⬅️ invoke() 사용
    print("응답:", response.content)



def main():
    """
    
    """
    lang_chain()

if __name__ == '__main__':
    main()
