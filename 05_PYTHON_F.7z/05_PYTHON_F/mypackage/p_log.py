import logging

# 로거 생성
logger = logging.getLogger("pcwk_logger")
logger.setLevel(logging.DEBUG)


# 핸들러 추가
console_handler = logging.StreamHandler()  # 콘솔 출력
file_handler = logging.FileHandler('pcwk_app.log', encoding='utf-8')  # 파일에 저장

# 포맷 설정
formatter = logging.Formatter('%(asctime)s [%(levelname)s] %(filename)s %(lineno)d - %(message)s',
                              datefmt='%Y-%m-%d %H:%M:%S')

console_handler.setFormatter(formatter)
file_handler.setFormatter(formatter)

# 로거에 핸들러 추가
logger.addHandler(console_handler)
logger.addHandler(file_handler)


def main():
    """

    """

    #로그 메시지 출력
    logger.debug('debug 메시지')
    logger.info('info 메시지')
    logger.warning('warning 메시지')
    logger.error('error 메시지')
    logger.critical('critical 메시지')

if __name__ == '__main__':
    main()
