import cx_Oracle

class OracleConnection:
    def __init__(self, user='scott', password='pcwk', dsn='192.168.100.30:1522/xe'):
        self.user = user
        self.password = password
        self.dsn = dsn

    def connect(self):
        return cx_Oracle.connect(self.user, self.password, self.dsn)


def main():
    """
    
    """


if __name__ == '__main__':
    main()
