def average(numbers):
    '''
    평균
    :param numbers:
    :return:  sum(numbers)/len(numbers)
    '''
    return sum(numbers)/len(numbers)