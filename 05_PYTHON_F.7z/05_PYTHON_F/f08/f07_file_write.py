def main():
    """
    
    """

    #파일 쓰기 : 한 줄씩 기록
    with open('pcwk_ex.txt','w',encoding='utf-8') as f:
        f.write('Python 파일 입출력 예제 입니다.\n')
        f.write('파일에 데이터를 저장 합니다.\n')

    #파일 여러줄 쓰기
    lines=['첫 번째 줄\n','두 번째 줄\n','세 번째 줄\n']
    with open(file='multilines.txt',mode='w',encoding='utf-8') as f:
        f.writelines(lines) #여러줄 쓰기





if __name__ == '__main__':
    main()
