def main():
    """
    파일에서 숫자를 읽어 합계, 평균, 최대, 최소을 계산합니다.
    """
    new_numbers = []
    with open('q2.txt','r',encoding='utf-8') as f:
        numbers_list_str = f.readlines()
        print(f'numbers:{numbers_list_str[0]}, type{type(numbers_list_str[0])}')
        new_numbers=numbers_list_str[0].split(",")

    #문자를 숫자로 변환 : 리스트 내포
    #converted_numbers:[10, 20, 30, 40, 50]
    converted_numbers = [int(num.strip()) for num in new_numbers]
    print(f'converted_numbers:{converted_numbers}')

    print(f'합계:{sum(converted_numbers)}')
    print(f'평균:{sum(converted_numbers)/len(converted_numbers)}')
    print(f'최대값:{max(converted_numbers)}')
    print(f'최소값:{min(converted_numbers)}')


if __name__ == '__main__':
    main()
