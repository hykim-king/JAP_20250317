from functools import reduce

# 리스트 요소의 합계 구하기
nums = [1,2,3,4,5]
#reduce(function,iterable) :
# iterable의 모든 요소를 누적하여 하나의 결과 값으로 줄이는
# 함수 functools 모듈에서 import 해야 사용 가능.

total = reduce(lambda x,y:x+y,nums)
print(f'total:{total}') #total:15


#초기값 10을 시작으로 누적
new_total=reduce(lambda x,y:x+y,nums,10)
print(f'new_total:{new_total}')