import json

def main():
    """
    파일 저장: uers.json
    """
    users = [
        {"id":1,'name':'이상무','age':21,'email':'james@paran.com'},
        {"id":2,'name':'홍당무','age':20,'email':'james02@paran.com'},
        {"id":3,'name':'영희','age':22,'email':'james03@paran.com'}
    ]

    # JSON 파일로 저장
    with open('users.json', 'w', encoding='utf-8') as f:
        json.dump(users, f, ensure_ascii=False, indent=4)


if __name__ == '__main__':
    main()
