import os
from pathlib import Path



def main():
    """
    
    """
    # if os.path.exists('pcwk_ex.txt'):
    #     print('파일이 존재 합니다.')
    # else:
    #     print('파일이 없습니다.')

    file=Path('pcwk_ex.txt')

    if file.is_file():
        print('파일이 존재 합니다.')
    else:
        print('파일이 없습니다.')


if __name__ == '__main__':
    main()
