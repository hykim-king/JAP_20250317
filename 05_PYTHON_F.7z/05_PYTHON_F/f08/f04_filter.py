#짝수만 필터링
nums = [1,2,3,4,5,6]

#filter(function,iterable):
# iterable의 각 요소 중 함수 조건에 맞는 값만 필터링하여 반환
evens=list(filter(lambda x:x%2 == 0,nums))

#evens:[2, 4, 6]
print(f'evens:{evens}')
