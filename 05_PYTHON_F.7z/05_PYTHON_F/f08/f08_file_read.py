def main():
    """

    """
    #파일 전체 읽기
    with open(file='pcwk_ex.txt', mode='r' ,encoding='utf-8') as f:
        content=f.read()
        print(f'content:{content}')

    # 파일 한 줄씩 읽기
    with open(file='pcwk_ex.txt', mode='r', encoding='utf-8') as f:
        for line in f:
            print(f'line:{line}',end='')

    print('#'*53)
    # 파일을 리스트로 읽기
    with open(file='pcwk_ex.txt', mode='r', encoding='utf-8') as f:
        lines = f.readlines()
        for str in lines:
            print(str,end="")

    # 파일 내용 추가
    with open(file='pcwk_ex.txt', mode='a', encoding='utf-8') as f:
        f.write('이 줄은 추가된 내용입니다.')


if __name__ == '__main__':
    main()
