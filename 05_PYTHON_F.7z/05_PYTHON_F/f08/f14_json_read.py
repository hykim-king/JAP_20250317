import json


def main():
    """
    ### JSON 데이터 읽기(Read from JSON)
    : json.load()
    """

    # JSON 데이터 읽기
    with open('data.json','r',encoding='utf-8') as f:
        load_data = json.load(f)

        #type:<class dict>
        print(f'load_data:{load_data},type:{type(load_data)}')

        #load_data['name']:이상무
        print(f'load_data[\'name\']:{load_data['name']}')
        #load_data['languages']:['Java', 'Python', 'Oracle']
        print(f'load_data[\'languages\']:{load_data['languages']}')




if __name__ == '__main__':
    main()
