import json
def main():
    """
    
    """
    content = []

    #JSON파일 읽기
    with open('users.json','r',encoding='utf-8') as f:
        content=json.load(f)
        print(f'content:{content},type:{type(content)}')


    content.append({"id":4,'name':'철수','age':23,'email':'james04@paran.com'})

    print(f'content:{content},type:{type(content)}')

    with open('users2.json','w',encoding='utf-8') as f:
            json.dump(content,f,ensure_ascii=False,indent=2)





if __name__ == '__main__':
    main()
