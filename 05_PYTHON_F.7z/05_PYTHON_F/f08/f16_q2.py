import  json
def main():
    """
    users.json파일 읽기
    """

    content = []

    #JSON파일 읽기
    with open('users.json','r',encoding='utf-8') as f:
        content=json.load(f)
        #type:<class list>
        print(f'content:{content},type:{type(content)}')


    for user in content:
        print(user['id'],user['name'],user['age'],user['email'])



if __name__ == '__main__':
    main()
