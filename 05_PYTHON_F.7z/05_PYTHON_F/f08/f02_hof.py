def make_multiplier(factor):
    def mutiply(x):
        return x * factor

    return mutiply


double = make_multiplier(2)
triple = make_multiplier(3)

print(double(5)) #10
print(triple(5)) #15