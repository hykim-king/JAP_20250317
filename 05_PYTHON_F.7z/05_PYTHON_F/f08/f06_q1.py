from functools import reduce
#1~20까지의 정수 중에서 짝수만 골라 제곱한 결과의 합을 구하시오.

#1. 1~20사이 정수
numbers=list(range(1,20+1))
#numbers:[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]

print(f'numbers:{numbers}')

#2. filter : 짝수만 골라
evens=list(filter(lambda x:x%2==0,numbers))
#evens:[2, 4, 6, 8, 10, 12, 14, 16, 18, 20]
print(f'evens:{ evens}')

#3. map # 제곱한 결과
squares=list(map(lambda x:x**2,evens))
print(f'squares:{ squares}')


#4. reduce  # 제곱한 결과
#squares:[4, 16, 36, 64, 100, 144, 196, 256, 324, 400]
result=reduce(lambda x,y:x+y,squares)
print(f'result:{result}') #result:1540



