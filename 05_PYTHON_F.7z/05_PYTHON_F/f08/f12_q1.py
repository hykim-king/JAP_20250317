def main():
    """
    사용자 입력 저장하고 ‘exit’를 입력 하면 프로그램 종료.
    """
    file_name = 'q1.txt'

    with open(file_name,'w', encoding='utf-8') as f:
        while True:
            text=input('저장할 내용을 입력 하세요(종료:exit)')

            if text.lower() =='exit':
                print(f'프로그램 종료!')
                break
            #파일에 입력 내용 기록
            f.write(text+'\n')


    print(f'{file_name} 파일이 생성되었습니다.')




if __name__ == '__main__':
    main()
