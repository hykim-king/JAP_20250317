def main():
    """
    불리언
    """
    is_happy = True
    is_sad = False

    print(type(is_happy)) #<class 'bool'>

    ##############################
    # ctrl + / : comment
    # - and : 두 값이 모두 참이면 True
    # - or : 하나라도 참이면 True
    # - not: 값을 반대로 뒤집음
    ##############################

    x = True
    y = False

    print(x and y) # False
    print(x or y) # True
    print(not y) # True
    ##############################

    print(True + 1)  #2
    print(False + 1) #1

    a = 5
    b = 3
    print(a & b)
    print(a ^ b)
    print(~a)
    print(a << 1)
    print(a >> 1)
if __name__ == '__main__':
    main()
