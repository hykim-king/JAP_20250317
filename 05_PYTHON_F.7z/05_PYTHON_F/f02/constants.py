# 상수
PI = 3.141592
MAX_USERS = 20
print(__name__)
print(PI)