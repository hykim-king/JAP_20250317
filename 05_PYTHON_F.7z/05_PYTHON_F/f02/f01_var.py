def main():
    """
    변수
    """

    #변수명 : 영문, 숫자, _ 사용 가능, 시작은 영문자로 시작
    valid_name = 10
    _name = "이상무"
    #2name = "error"

    #대소문자 구분
    Name = "이상무"
    name = "Alice"

    print(Name)
    print(name)

    ##########################
    #실행: ctrl+shift+F10
    ##########################
    #공백 특수 문자 사용 금지
    #my-name ="error"
    #my name ="error"

    #한글 변수 선언 가능: 현장에선 사용하지 않는다.
    이름 = '홍길동'
    print(이름)

    #여러 변수 한 번에 할당
    a,b,c =1,2,3
    print(a,b,c)
    x = y = z =100
    print(x, y, z)

    #type()
    name = "이상무"
    age  = 22
    height = 177.8

    print(type(name)) # <class 'str'>
    print(type(age))  # <class 'int'>
    print(type(height))#<class 'float'>


    #상수
    PI = 3.141592
    MAX_USERS = 20

    #PI = '파이'
    print(PI)
    print(MAX_USERS)
    print(__name__)
if __name__ == '__main__':
    main()
