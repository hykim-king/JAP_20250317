def main():
    """
    
    """
    name = "이상무"
    greeting = '즐거운 목요일 2일전'

    print(type(name))
    print(type(greeting))
    #################################
    full_name = "이" + " " + "상무"
    print(full_name)

    #################################
    repeated = "Hi!" * 10
    print("-" * 57)
    print(repeated)
    print("-"*57)

    #################################
    text = "Python"

    print(text[0]) # 첫 번째 문자: P
    print(text[-1])  # 마지막 문자: n
    print(text[1:4])  # 부분 문자: yth, 시작은 포함, 끝은 미포함




if __name__ == '__main__':
    main()
