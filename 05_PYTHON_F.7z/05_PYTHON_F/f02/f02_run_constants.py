import constants

def main():
    """
    상수 호출
    """
    print(constants.PI)
    print(constants.MAX_USERS)

if __name__ == '__main__':
    main()
