class Person:
    '''
    사람 클래스
    '''
    def __init__(self, name):
        self._name = name  # 관례적으로 _로 보호 (protected 수준)


    @property
    def name(self):        # getter
        return self._name

    @name.setter
    def name(self, value): # setter
        if not value:
            raise ValueError("이름은 비어 있을 수 없습니다.")
        self._name = value
        
p=Person(name='이상무')

print(f'p.name: {p.name}')

p.name='홍당무'
print(f'p.name: {p.name}')
