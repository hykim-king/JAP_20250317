from openpyxl import Workbook

def main():
    """
    
    """
    # 새 워크북 생성
    wb=Workbook()


    # 시트 선택
    ws=wb.active
    # 시트 이름 지정
    ws.title ='PCWK_403_Sheet'


    #데이터 쓰기
    ws['A1'] = '이름'
    ws['B1'] = '나이'

    ws.append(['영희',22]) # 행추가
    ws.append(['철수', 21])  # 행추가

    #파일 저장
    wb.save('address_book.xlsx')
    print('Excel 파일이 생성되었습니다.')


if __name__ == '__main__':
    main()
