import re

def main():
    """
    
    """

    #538.휴면예금[Dormant Deposit]

    text = '''
				538.
				휴면예금
					[Dormant Deposit]
				'''
    #한글만, 숫자
    #한글 : 가-힣
    #숫자 : 0-9
    #영문 소문자 : a-z
    #영문 대문자 : A-Z

    print(f'text:{text}')
    cleaned=re.sub(r'[^가-힣0-9a-zA-Z. \[\]]','',text)
    print(f'cleaned:{cleaned}')


if __name__ == '__main__':
    main()

