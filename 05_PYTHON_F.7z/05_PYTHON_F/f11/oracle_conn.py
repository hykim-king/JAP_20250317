import cx_Oracle
from numpy.f2py.crackfortran import usermodules


def do_retrieve():
    '''
    전체 조회
    :return:
    '''
    try:
        conn = None  # connection
        cursor = None  # 커서

        # 데이터베이스 연결 시도
        conn = cx_Oracle.connect( 'scott', 'pcwk', ' 192.168.100.30:1522/XE')
        print(f'conn:{conn}')

        # SQL 실행
        cursor = conn.cursor()
        print(f'cursor:{cursor}')

        sql_select_all = 'SELECT * FROM emp'
        cursor.execute(sql_select_all)
        for row in cursor:
            print(row)

    except cx_Oracle.DatabaseError as e:
        # 데이터베이스 관련 예외 처리
        error, = e.args
        print(f" Oracle 데이터베이스 오류 발생: {error.message}")
    except Exception as e:
        print(f'Exception:{e}')
    else:
        print(f'정상 종료!')
    finally:
        # 리소스 해제
        try:
            if cursor:
                cursor.close()
                print(f'cursor:{cursor}')
            if conn:
                conn.close()
                print(f'conn:{conn}')

        except:
            pass  # 예외 중첩 방지용

def do_insert(param):
    '''
    단건 등록!
    :param param:
    :return:
    '''
    try:
        conn = None  # connection
        cursor = None  # 커서

        # 데이터베이스 연결 시도
        conn = cx_Oracle.connect('scott', 'pcwk', ' 192.168.100.30:1522/XE')
        print(f'conn:{conn}')

        # SQL 실행
        cursor = conn.cursor()
        print(f'cursor:{cursor}')

        insert_sql = 'INSERT INTO emp (empno, ename, deptno) VALUES (:1, :2, :3)'
        data = param
        print(f'param:{param}')
        print(f'sql:{insert_sql}')


        cursor.execute(insert_sql, data)

        # 성공 시 커밋
        conn.commit()
        print("데이터 삽입 성공 및 커밋 완료")
    except cx_Oracle.DatabaseError as e:
        # 데이터베이스 관련 예외 처리
        # 오류 발생 시 롤백
        conn.rollback()

        error, = e.args
        print(f" Oracle 데이터베이스 오류 발생, 롤백 수행: {error.message}")
    except Exception as e:
        # 오류 발생 시 롤백
        conn.rollback()
        print(f'일반 오류 발생, 롤백 수행:{e}')
    else:
        print(f'정상 종료!')
    finally:
        # 리소스 해제
        try:
            if cursor:
                cursor.close()
                print(f'cursor:{cursor}')
            if conn:
                conn.close()
                print(f'conn:{conn}')

        except:
            pass  # 예외 중첩 방지용


def main():
    """
    
    """
    data = (9999, "TEST_PCWK", 10)

    do_insert(data)


    do_retrieve()





if __name__ == '__main__':
    main()
