import logging

def main():
    """
    
    """

    #기본 설정
    logging.basicConfig(
        filename='pcwk_log.log',
        level=logging.DEBUG,
        format='%(asctime)s [%(levelname)s] %(filename)s %(lineno)d - %(message)s',datefmt='%Y-%m-%d %H:%M:%S'
    )


    #로그 메시지 출력
    logging.debug('debug 메시지')
    logging.info('info 메시지')
    logging.warning('warning 메시지')
    logging.error('error 메시지')
    logging.critical('critical 메시지')




if __name__ == '__main__':
    main()
