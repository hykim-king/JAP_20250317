import requests
from bs4 import BeautifulSoup
import re
from openpyxl import Workbook

def fine():
    print(f'fine()')
    #크롤링
    list_titles = []    #용어
    list_contents = []  #용어 설명

    fDic = {} #용어:설명

    try:
        for i in range(1,54+1):
        #for i in range(1,2):
            #print(f'i:{i}',end=',')
            url = f'https://fine.fss.or.kr/fine/fnctip/fncDicary/list.do?menuNo=900021&src=&kind=&searchCnd=1&searchStr=&pageIndex={i}'
            #print(f'url:{url}')

            #웹사이트 접속
            response=requests.get(url)

            if 200 == response.status_code:
                #print(f'접속성공:\n{response.text}')
                html=response.text

                #BeautifulSoup객체 생성
                bs=BeautifulSoup(html, 'html.parser')

                #용어
                titles=bs.select('div.result-list dl dt')
                #print(f'titles:{type(titles)}')

                for title in titles:
                    #print(f'title.text:\n{title.text}')
                    cleaned_title = re.sub(r'[^가-힣0-9a-zA-Z. \[\]]', '', title.text)
                    #print(f'cleaned_title:\n{cleaned_title}')
                    list_titles.append(cleaned_title)


                print(f'list_titles:\n{list_titles}')

                #용어설명
                contents = bs.select('div.result-list dl dd')
                for content in contents:
                    #print(f'content:\n{content.text}')
                    list_contents.append(content.text)

                print(f'list_contents:\n{list_contents}')


                #용어:용어설명
                print(f'list_titles len:{len(list_titles)}')
                print(f'list_contents len:{len(list_contents)}')

                # 용어:용어설명 -> Dic(key:value -> 용어:용어설명)

                for i in range(0,len(list_titles)):
                    #print(f'{i}',end=',')
                    fDic[list_titles[i]]= list_contents[i]


                print(f'fDic:\n{fDic}')


            else:
                print(f'접속실패:{response.text}')




    except ConnectionError as e:
        print(f'ConnectionError(접속오류):{e}')
    except Exception as e:
        print(f'Exception:{e}')
    else:
        print('#'*53)
        print(f'# 정상적으로 프로그램이 종료 되었습니다.')
        print('#' * 53)
    finally:
        print(f'항상 수행')


    return fDic;


def writeXlsx(fineDic):
    #print(f'writeXlsx fineDic:{fineDic}')

    # 새 워크북 생성
    wb=Workbook()

    # 시트 선택
    ws=wb.active

    #시트이름 지정
    ws.title ='fine_금융용어'


    #데이터 쓰기
    ws['A1'] = '금융 용어'
    ws['B1'] = '설명'

    for key in fineDic.keys():
        ws.append([key, fineDic.get(key)])

    #파일에 저장
    wb.save('금융용어사전_2025_08_07.xlsx')

    print('금융용어사전_2025_08_07.xlsx 파일이 생성되었습니다.')




def main():
    """
    
    """
    #fine 클롤링
    fineDic=fine()
    #print(f'99fineDic:{fineDic}')

    #엑셀 저장
    writeXlsx(fineDic)

if __name__ == '__main__':
    main()
