from openpyxl import load_workbook

def main():
    """
    
    """

    #Excel 파일 열기: Workbook
    wb=load_workbook('address_book.xlsx')

    #Sheet선택
    ws=wb.active

    #데이터 읽기
    #values_only=True : 값만 읽음
    for row in ws.iter_rows(values_only=True):
        print(f'row:{row}')

    #셀값 읽기
    print(f'ws[\'A2\'].value:{ws['A2'].value}') #영희
    print(f'{ws.cell(2,2).value}') #22

    #셀값 쓰기
    ws['C1'] ='점수'
    ws['C2'] =70
    ws['C3'] =75

    #저장
    wb.save('new_address_book.xlsx')
    print(f'new_address_book.xlsx 파일이 생성되었습니다.')


if __name__ == '__main__':
    main()
