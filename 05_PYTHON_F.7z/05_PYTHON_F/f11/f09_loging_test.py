from mypackage.p_log import  logger as log

def main():
    """
    
    """

    #로그 메시지 출력
    log.debug('debug9 메시지')
    log.info('info9 메시지')
    log.warning('warning9 메시지')
    log.error('error9 메시지')
    log.critical('critical9 메시지')



if __name__ == '__main__':
    main()
