import pandas as pd

def main():
    """
    
    """
    try:
        df=pd.read_excel('pandas_address.xlsx', engine='openpyxl')
    except FileNotFoundError as e:
        print(f'파일을 찾을수 없습니다.:{e}')
    except ValueError as e:
        print(f'파일 읽기 오류:{e}')
    except Exception as e:
        print(f'Exception:{e}')

    print(f'df:\n{df}')

if __name__ == '__main__':
    main()
