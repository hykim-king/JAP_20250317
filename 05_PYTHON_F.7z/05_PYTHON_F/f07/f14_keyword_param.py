def greet(name, message):
    '''
    키워드 파라메터
    :param name:
    :param message:
    :return:
    '''

    print(f'{name}, {message}')

greet(message='안녕하세요',name='영희님')
greet(name='영희님',message='안녕하세요')