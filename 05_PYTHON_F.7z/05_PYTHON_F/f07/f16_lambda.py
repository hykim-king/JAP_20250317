def add(a,b):
    '''
    일반 함수
    :param a:
    :param b:
    :return:
    '''
    return a+b


#람다식
add_lambda=lambda a, b:a+b

print(add(14,16))
print(add_lambda(14,16))



def main():
    """
    
    """


if __name__ == '__main__':
    main()
