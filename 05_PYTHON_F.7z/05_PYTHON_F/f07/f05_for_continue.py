def main():
    """
    
    """
    for i in range(1,11):
        if i % 2 ==0:
            continue

        print(f'i:{i}')

    #####################################################
    print(f'#'*53)

    comments = ["좋아요!", "별로에요", "최고예요", "싫어요", "좋았어요"]

    for comment  in comments:
        if '좋' not in comment:
            continue

        print(comment)





if __name__ == '__main__':
    main()
