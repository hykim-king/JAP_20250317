def main():
    """
    while
    """

    i = 1
    while i<=5:
        print(i)
        i = i+1
    #####################################################
    print('#'*53)

    count =5

    while count > 0:
        print(count)
        count -= 1
    else:   #break가 없으면 반복 종료 후 else 실행.
        print('카운트 다운 종료!')


    #####################################################
    print('#'*53)

    n = 12

    for i in range(2,n):
        if n % i ==0:
            print(f'{n}은 소수가 아닙니다.')
            break
    else:
        print(f'{n}은 소수가 입니다.')

if __name__ == '__main__':
    main()
