def main():
    """
    [ 표현식 for 항목 in 반복가능한 객체 if 조건 ]
    """

    numbers = [1,2,3,4,5]
    squares = [ i * i for i in numbers]

    print(f'numbers:{numbers}')
    print(f'squares:{squares}')

    # numbers: [1, 2, 3, 4, 5]
    # squares: [1, 4, 9, 16, 25]

    print('#'*53)
    #####################################################
    #[0, 2, 4, 6, 8]

    even_numbers = [n for n in range(1,10)if n % 2 ==0]
    print(f'even_numbers:{even_numbers}')

    print('#'*53)
    #####################################################
    #2차원 리스트 내포
    #출력: [[1, 2, 3], [2, 4, 6], [3, 6, 9]]

    matrix = [ [ i*j for j in range(1,4)] for i in range(1,4)  ]
    print(f'matrix:{matrix}')

    #딕셔너리 내포(Dictionary Comprehension)
    nums = [1,2,3,4]
    # {1: 1, 2: 4, 3: 9, 4: 16}

    square_dict={x:x ** 2 for x in nums}
    print(f'square_dict:{square_dict}')


    #집합 내포(Set Comprehension)
    # 1 ~ 10 중 3의 배수의 제곱
    s= {x**2 for x in range(1,11) if x % 3==0 }
    print(f's:{s},type:{type(s)}')



if __name__ == '__main__':
    main()
