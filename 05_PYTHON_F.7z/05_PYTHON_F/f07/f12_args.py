
def add_numbers(*args):
    '''
    여러 값을 튜플로 전달
    :param args:
    :return:
    '''
    return sum(args)

def main():
    """
    
    """
    print(add_numbers(1,2,3,4,5))




if __name__ == '__main__':
    main()
