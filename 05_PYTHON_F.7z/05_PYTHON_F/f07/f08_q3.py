def main():
    """
    
    """


    # 1. 숫자를 하나 입력 받는다.
    # 2. 0을 입력 하면 종료
    # 3. 숫자 피라미드 출력

    while True:

        rows = int(input('숫자 피라미드 높이를 입력 하세요 9이하 입력>'))
        if rows>=10:
            print('9단 이하 입력 하세요.')
            continue


        if rows == 0:
            print('프로그램을 종료 합니다.')
            break

        print(f'피라미드 높이:{rows}')

        for i in range(1,rows+1):
            print(" "*(rows-i)+str(i)*i)
            #print(f'i:{i}')










if __name__ == '__main__':
    main()
