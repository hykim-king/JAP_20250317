def main():
    """
    리스트 반복
    """
    #
    fruits =['사과','바나나','복숭아']

    for fruit in fruits:
        print(fruit,sep="",end="\t")

    #####################################################
    print('#'*53)

    #문자열 반복
    text = "Python"

    for char in text:
        print(char)


    #
    user_list = [(1,19),(2,16),(3,14)]
    print(f'user_list:{user_list}, type:{type(user_list)}')
    for (first,last) in user_list:
        print(first, last)

    ############################################
    print('#' * 53)
    #range(시작,끝,증감)

    for i in range(1,11,2):
        print(i,end=",")

    print()

    for i in range(10,0,-1):
        print(i,end=",")

    print()
    #list()와 함께 사용
    numbers=list(range(1,11))
    print(f'numbers:{numbers}')




if __name__ == '__main__':
    main()
