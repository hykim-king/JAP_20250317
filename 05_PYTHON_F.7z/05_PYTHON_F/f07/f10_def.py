def greet():
    print('안녕하세요!')


greet()

####################################


def greet(name):
    print(f'안녕하세요, {name}님')

greet('이상무')

####################################

def add(a,b):
    return a+b

result=add(14,16)
print(f'result:{result}')

####################################

def add_and_substract(x,y):
    '''
    return을 여러개 할수 있음
    :param x:
    :param y:
    :return x+y, x-y:
    '''

    return x+y, x-y



add_result,substract_result=add_and_substract(16,14)
print(f'add_result:{add_result}')
print(f'substract_result:{substract_result}')