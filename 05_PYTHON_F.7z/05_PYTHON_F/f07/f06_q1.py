def main():
    """
    
    """

    result = 0 #합계
    i =1
    while i<=1000:
        if i % 3 ==0:
            result +=i

        i+=1
    print(f'result:{result}')

if __name__ == '__main__':
    main()
