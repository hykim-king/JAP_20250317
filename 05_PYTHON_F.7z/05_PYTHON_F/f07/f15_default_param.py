def order(item, quantity=1, price=1000):
    total = quantity * price
    print(f'{quantity}개 {item}: 주문 합계:{total}원')

order('수박맛 바',quantity=3)
order('메론',price=2000)