def main():
    """
    
    """
    # 1. 숫자를 하나 입력 받는다.
    # 2. 음수면 다시 입력 받는다.
    # 3. 양수이면 패토리얼을 계산한다.
    # 4. 0을 입력 하면 종료

    while True:
        number = int(input('양의 정수를 입력 하세요.\n(0을 입력하면 종료!)>'))

        if number < 0:
            print(f'{number} 양수를 입력 하세요.')
            continue

        if number == 0:
            print('프로그램을 종료 합니다.')
            break

        factorial = 1

        for i in range(1,number+1):
            factorial*=i
            print(f'factorial:{factorial},i={i}')

        print(f'{number}! = {factorial}')







if __name__ == '__main__':
    main()
