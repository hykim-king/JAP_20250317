students = [("홍길동", 90), ("김철수", 80), ("이영희", 85)]
print(f'sort전 students:{students}')
students.sort(key=lambda x:x[1])
print(f'sort후 students:{students}')


print('#'*53)
#####################################################
numbers = [1, 2, 3, 4, 5, 6]
even_number=list(filter(  lambda x:x % 2 ==0, numbers))
print(f'even_number:{even_number}')

