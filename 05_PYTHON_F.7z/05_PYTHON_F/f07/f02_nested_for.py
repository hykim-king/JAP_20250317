def main():
    """
    
    """

    #구구단
    for dan in range(2,10):
        for j in range(1,10):
            print(f'{dan} * {j} = {dan*j}')
        print()





if __name__ == '__main__':
    main()
