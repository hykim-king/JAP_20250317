from dataclasses import dataclass
from typing import Optional

@dataclass
class Emp:
    empno: int                # 사번
    ename: str                # 사원 이름
    job: str                  # 직무
    mgr: Optional[int] = None # 관리자 사번 (nullable)
    hiredate: Optional[str] = None  # 입사일 (문자열 혹은 datetime 타입 가능)
    sal: Optional[float] = None     # 급여
    comm: Optional[float] = None    # 커미션
    deptno: Optional[int] = None    # 부서 번호


# 객체 생성
#emp = Emp(empno=1234, ename='JANE', job='CLERK', mgr=7839, hiredate='2023-01-01', sal=2000.0, comm=None, deptno=10)
#print(emp)

#필드 접근
#print(emp.ename)