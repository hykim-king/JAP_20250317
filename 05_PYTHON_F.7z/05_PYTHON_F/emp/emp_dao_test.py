from emp import Emp
from mypackage.db import OracleConnection
from emp_dao import EmpDAO

def do_retrieve():
    # 연결 정보 설정
    db = OracleConnection()
    dao = EmpDAO(db)

    emps=dao.do_retrieve()

    for emp in emps:
        print(emp.empno,emp.ename)



def do_update():
    # 연결 정보 설정
    db = OracleConnection()
    dao = EmpDAO(db)

    # CREATE
    new_emp = Emp(empno=9999, ename="LEE", job="ANALYST", mgr=7839,
                  hiredate="2024-08-01", sal=4000+500, comm=None, deptno=20)


    flag = dao.do_update (new_emp)

    if 1 == flag:
        print('수정 성공:', flag)
    else:
        print('수정 실패:', flag)

def do_selectone():
    # 연결 정보 설정
    db = OracleConnection()
    dao = EmpDAO(db)
    new_emp = Emp(empno=9999, ename="LEE", job="ANALYST", mgr=7839,
                  hiredate="2024-08-01", sal=4000, comm=None, deptno=20)

    emp=dao.do_selectone(new_emp.empno)
    if emp:
        print(f'emp:{emp}')
    else:
        print(f'조회 실패')

def do_delete():
    # 연결 정보 설정
    db = OracleConnection()
    dao = EmpDAO(db)

    # CREATE
    new_emp = Emp(empno=9999, ename="LEE", job="ANALYST", mgr=7839,
                  hiredate="2024-08-01", sal=4000, comm=None, deptno=20)


    flag = dao.do_delete(new_emp.empno)

    if 1 == flag:
        print('삭제 성공:', flag)
    else:
        print('삭제 실패:', flag)

def do_insert():
    # 연결 정보 설정
    db = OracleConnection()
    dao = EmpDAO(db)

    # CREATE
    new_emp = Emp(empno=9999, ename="LEE", job="ANALYST", mgr=7839,
                  hiredate="2024-08-01", sal=4000, comm=None, deptno=20)
    flag = dao.do_insert(new_emp)

    if 1 == flag:
        print('등록 성공:',flag)
    else:
        print('등록 실패:', flag)



def main():
    """
    
    """
    do_delete()
    do_insert()
    do_update()
    do_selectone()
    do_retrieve()

if __name__ == '__main__':
    main()
