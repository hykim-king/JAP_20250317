from mypackage.db import OracleConnection
from emp import Emp
import cx_Oracle

class EmpDAO:
    def __init__(self, db: OracleConnection):
        self.db = db


    def do_retrieve(self):
        conn = self.db.connect()
        cursor = conn.cursor()
        result = []
        try:

            cursor.execute("SELECT empno, ename, job, mgr, TO_CHAR(hiredate, 'YYYY-MM-DD'), sal, comm, deptno FROM emp")
            for row in cursor.fetchall():
                print(f'row:{row},type:{type(row)}')
                emp = Emp(*row)
                result.append(emp)

        except cx_Oracle.DatabaseError as e:
            # 데이터베이스 관련 예외 처리
            # 오류 발생 시 롤백
            conn.rollback()

            error, = e.args
            print(f" Oracle 데이터베이스 오류 발생, 롤백 수행: {error.message}")
        except Exception as e:
            conn.rollback()
            print("INSERT 실패:", e)
        finally:
            cursor.close()
            conn.close()

        return result;

    def do_update(self, emp: Emp):
        flag = 0 #반영 건수
        conn = self.db.connect()
        cursor = conn.cursor()
        try:
            sql = """
                UPDATE emp SET sal = :1 WHERE empno = :2
            """
            cursor.execute(sql, (
                emp.sal,emp.empno
            ))
            conn.commit()

            flag = cursor.rowcount
            print(f'변경된 행 수:',flag)

            print("do_update 성공")
        except cx_Oracle.DatabaseError as e:
            # 데이터베이스 관련 예외 처리
            # 오류 발생 시 롤백
            conn.rollback()

            error, = e.args
            print(f" Oracle 데이터베이스 오류 발생, 롤백 수행: {error.message}")
        except Exception as e:
            conn.rollback()
            print("INSERT 실패:", e)
        finally:
            cursor.close()
            conn.close()

        return flag


    def do_selectone(self,empno:int)->Emp:

        conn = self.db.connect()
        cursor = conn.cursor()
        try:

            cursor.execute("SELECT * FROM emp WHERE empno = :1", [empno])
            row = cursor.fetchone()

            if row:
                return Emp(*row)
            else:
                print("해당 사원이 존재하지 않습니다.")

            print(f'row:',row)
        except cx_Oracle.DatabaseError as e:
            # 데이터베이스 관련 예외 처리
            # 오류 발생 시 롤백
            conn.rollback()

            error, = e.args
            print(f" Oracle 데이터베이스 오류 발생, 롤백 수행: {error.message}")
        except Exception as e:
            conn.rollback()
            print("INSERT 실패:", e)
        finally:
            cursor.close()
            conn.close()



    def do_delete(self,empno:int):
        flag = 0 #반영 건수
        conn = self.db.connect()
        cursor = conn.cursor()
        try:
            sql = """
                DELETE FROM emp WHERE empno = :1
            """
            cursor.execute(sql, [empno])
            conn.commit()

            flag = cursor.rowcount
            print(f'변경된 행 수:',flag)

            print("삭제 성공")
        except cx_Oracle.DatabaseError as e:
            # 데이터베이스 관련 예외 처리
            # 오류 발생 시 롤백
            conn.rollback()

            error, = e.args
            print(f" Oracle 데이터베이스 오류 발생, 롤백 수행: {error.message}")
        except Exception as e:
            conn.rollback()
            print("INSERT 실패:", e)
        finally:
            cursor.close()
            conn.close()

        return flag


    def do_insert(self, emp: Emp):
        flag = 0 #반영 건수
        conn = self.db.connect()
        cursor = conn.cursor()
        try:
            sql = """
                INSERT INTO emp (empno, ename, job, mgr, hiredate, sal, comm, deptno)
                VALUES (:1, :2, :3, :4, TO_DATE(:5, 'YYYY-MM-DD'), :6, :7, :8)
            """
            cursor.execute(sql, (
                emp.empno, emp.ename, emp.job, emp.mgr,
                emp.hiredate, emp.sal, emp.comm, emp.deptno
            ))
            conn.commit()

            flag = cursor.rowcount
            print(f'변경된 행 수:',flag)

            print("INSERT 성공")
        except cx_Oracle.DatabaseError as e:
            # 데이터베이스 관련 예외 처리
            # 오류 발생 시 롤백
            conn.rollback()

            error, = e.args
            print(f" Oracle 데이터베이스 오류 발생, 롤백 수행: {error.message}")
        except Exception as e:
            conn.rollback()
            print("INSERT 실패:", e)
        finally:
            cursor.close()
            conn.close()

        return flag