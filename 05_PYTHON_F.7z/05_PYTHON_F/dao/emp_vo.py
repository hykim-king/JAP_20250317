from dataclasses import dataclass
from typing import Optional

@dataclass
class EmpVO:
    empno:int                    #사번
    ename:str                    # 이름
    job:str                      # 직무
    mgr:Optional[int] =None      # 매니저
    hiredate:Optional[str]=None  # 입사일
    sal:Optional[float]=None     # 급여
    comm:Optional[float]=None    # 상여금
    deptno:Optional[int]=None    # 부서번호




def main():
    """
    
    """
    emp01=EmpVO(empno='7369',ename='SMITH',job='CLERK',mgr=7839, hiredate='2025-08-08', sal=10000.0,comm=None,deptno=10)
    print(f'emp01:{emp01}')

    print(f'emp01.ename:{emp01.ename}')

if __name__ == '__main__':
    main()
