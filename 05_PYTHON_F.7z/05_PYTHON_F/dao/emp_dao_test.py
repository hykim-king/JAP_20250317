from mypackage.oracle_db import OracleConnection
from emp_vo import EmpVO
from emp_dao import EmpDAO


def do_retrieve():
    print(f'do_retrieve()')
    db=OracleConnection()
    dao=EmpDAO(db)
    result = dao.do_retrieve(page_no=2,page_size=10)

    if len(result) >0 :
        print('-' * 53)
        print('-' + '목조조회 성공')
        print('-' * 53)

        for empVO in result:
            print(f'empVO:{empVO}')

    else:
        print('-' + '목록조회 실패')



def do_retieve_all():
    print(f'do_retieve_all()')
    db=OracleConnection()
    dao=EmpDAO(db)

    result = dao.do_retrieve_all()

    if len(result) >0 :
        print('-' * 53)
        print('-' + '전체조회 성공')
        print('-' * 53)

        for empVO in result:
            print(f'empVO:{empVO}')

    else:
        print('-' + '전체조회 실패')


def do_update():
    print(f'do_update()')

    db=OracleConnection()
    dao=EmpDAO(db)

    up_emp=EmpVO(empno=9999,ename='LEE_U',job='ANALYST_U',mgr=7902
          , hiredate='2025-08-15',sal=9999, comm=100, deptno=30)

    flag=dao.do_update(emp=up_emp)

    if 1==flag:
        print('-'*53)
        print('-'+'수정 성공')
        print('-' * 53)
    else:
        print('-' + '수정 실패')



def do_selectone():
    print(f'do_selectone()')
    db=OracleConnection()
    dao=EmpDAO(db)

    emp=dao.do_selectone(empno=7839)

    if emp:
        print('-' * 53)
        print(f'emp:{emp}')
        print('-' + '조회 성공')
        print('-' * 53)
    else:
        print('-' + '조회 실패')

    pass


def do_delete():
    print(f'do_delete()')
    db=OracleConnection()
    dao=EmpDAO(db)

    flag=dao.do_delete(empno=9999)
    
    
    if 1==flag:
        print('-'*53)
        print('-'+'삭제 성공')
        print('-' * 53)
    else:
        print('-' + '삭제 실패')
    
def do_insert():
    print(f'do_insert()')

    db=OracleConnection()
    dao=EmpDAO(db)

    # print(f'db:{db}')
    # print(f'dao:{dao}')
    # print(f'db.connect:{db.connect()}')

    new_emp=EmpVO(empno=9999,ename='LEE',job='ANALYST',mgr=7839
          , hiredate='2025-08-11',sal=9999, comm=None, deptno=20)

    flag=dao.do_insert(emp=new_emp)

    if 1==flag:
        print('-'*53)
        print('-'+'등록 성공')
        print('-' * 53)
    else:
        print('-' + '등록 실패')


def main():
    """
    ctrl+shift+f10 : 실행
    """
    # do_delete()
    # do_insert()
    # do_selectone()
    # do_update()
    #do_retieve_all()
    do_retrieve()


if __name__ == '__main__':
    main()
