from sqlalchemy.sql.operators import comma_op

from mypackage.oracle_db import OracleConnection
from emp_vo import EmpVO
import cx_Oracle


class EmpDAO:
    def __init__(self, db:OracleConnection):
        self.db =db

    def do_retrieve(self, page_no:int=1, page_size:int=10):
        conn = self.db.connect()  # DB 커넥션
        cursor = conn.cursor()  # cursor
        result = [] #목록 조회 데이터
        try:
            sql = '''
            SELECT *
              FROM emp
             ORDER BY empno DESC
             OFFSET :page_size * (:page_no - 1) ROWS FETCH NEXT :page_size ROWS ONLY            
            '''
            print(f'1. param page_no:{page_no},page_size:{page_size} ')
            print(f'2. sql:\n{sql}')

            cursor.execute(sql,{
                "page_no": page_no,
                "page_size": page_size
            })

            for row in cursor:
                print(f'row:{row}, type:{type(row)}')
                result.append(EmpVO(*row))  # row -> EmpVO result에 추가
            print(f'result:{result}')
        except cx_Oracle.DatabaseError as e:
            # 데이터베이스 관련 예외 처리

            error = e.args
            print(f'데이터베이스 오류발생, 롤백 수행:{error[0].message}')
        except Exception as e:
            # 데이터베이스 관련 예외 처리

            print(f'목록 조회 실패:{e}')
        else:
            print('*' * 53)
            print('*목록 조회 성공')
            print('*' * 53)
        finally:
            # 리소스 해제
            try:
                if cursor:
                    cursor.close()

                if conn:
                    conn.close()
            except:
                pass  # 예외 중첩 방지용


        return result


    def do_retrieve_all(self):
        '''
        전체 조회
        :return:
        '''
        conn = self.db.connect()  # DB 커넥션
        cursor = conn.cursor()  # cursor
        result = [] #목록 조회 데이터
        try:
            sql = '''
                SELECT
                    empno,
                    ename,
                    job,
                    mgr,
                    hiredate,
                    sal,
                    comm,
                    deptno
                FROM
                    emp
                ORDER BY empno desc            
            '''
            print(f'1. param :없음')
            print(f'2. sql:\n{sql}')
            cursor.execute(sql)

            for row in cursor.fetchall():
                print(f'row:{row}, type:{type(row)}')

                result.append(EmpVO(*row)) #row -> EmpVO result에 추가


        except cx_Oracle.DatabaseError as e:
            # 데이터베이스 관련 예외 처리

            error = e.args
            print(f'데이터베이스 오류발생, 롤백 수행:{error[0].message}')
        except Exception as e:
            # 데이터베이스 관련 예외 처리

            print(f'전체 조회 실패:{e}')
        else:
            print('*' * 53)
            print('*전체 조회 성공')
            print('*' * 53)
        finally:
            # 리소스 해제
            try:
                if cursor:
                    cursor.close()

                if conn:
                    conn.close()
            except:
                pass  # 예외 중첩 방지용

        return result

    def do_update(self,emp:EmpVO):
        flag = 0 #반영건수
        conn = self.db.connect()  # DB 커넥션
        cursor = conn.cursor()    # cursor

        sql = '''
            UPDATE emp
            SET  
                ename = :ename,
                job = :job,
                mgr = :mgr,
                hiredate = :hiredate,
                sal = :sal,
                comm = :comm,
                deptno = :deptno
            WHERE
                    empno = :empno        
        '''
        try:
            print(f'1. param:{emp}')
            print(f'2. sql:{sql}')

            cursor.execute(sql,{
                "ename"   : emp.ename,
                "job"     : emp.job,
                "mgr"     : emp.mgr,
                "hiredate": emp.hiredate,
                "sal"     : emp.sal,
                "comm"    : emp.comm,
                "deptno"  : emp.deptno,
                "empno"   : emp.empno
            })
            conn.commit()

            flag=cursor.rowcount
            print(f'3. 반영건수:{flag}')

        except cx_Oracle.DatabaseError as e:
            # 데이터베이스 관련 예외 처리
            # 오류발생시 롤백
            conn.rollback()
            error = e.args
            print(f'데이터베이스 오류발생, 롤백 수행:{error[0].message}')
        except Exception as e:
            # 데이터베이스 관련 예외 처리
            # 오류발생시 롤백
            conn.rollback()
            print(f'update실패:{e}')
        else:
            print('*' * 53)
            print('*update 성공')
            print('*' * 53)
        finally:
            # 리소스 해제
            try:
                if cursor:
                    cursor.close()

                if conn:
                    conn.close()
            except:
                pass  # 예외 중첩 방지용

        return flag


    def do_selectone(self,empno:int):
        conn = self.db.connect()  # DB 커넥션
        # cursor: 데이터베이스 연결에서 SQL문을 실행하고 결과를 주고받는 작업 단위 객체
        cursor = conn.cursor()  # cursor

        try:
            sql = ''' 
                    SELECT
                        empno,
                        ename,
                        job,
                        mgr,
                        hiredate,
                        sal,
                        comm,
                        deptno
                    FROM
                        emp
                    WHERE empno = :empno               
             '''

            print(f'1. param empno:{empno}')
            print(f'2. sql:\n{sql}')

            cursor.execute(sql,{'empno':empno})

            row=cursor.fetchone() #단건 조회
            print(f'3. row:\n{row}')


            if row:
                return EmpVO(*row)
            else:
                print(f'해상 사원이 존재하지 않습니다.')

        except cx_Oracle.DatabaseError as e:
            # 데이터베이스 관련 예외 처리

            error = e.args
            print(f'데이터베이스 오류발생, 롤백 수행:{error[0].message}')
        except Exception as e:
            # 데이터베이스 관련 예외 처리

            print(f'단건 조회 실패:{e}')
        else:
            print('*' * 53)
            print('*단건 조회 성공')
            print('*' * 53)
        finally:
            # 리소스 해제
            try:
                if cursor:
                    cursor.close()

                if conn:
                    conn.close()
            except:
                pass  # 예외 중첩 방지용



    def do_delete(self,empno:int):
        flag =0
        conn=self.db.connect()# DB 커넥션
        #cursor: 데이터베이스 연결에서 SQL문을 실행하고 결과를 주고받는 작업 단위 객체
        cursor=conn.cursor() # cursor
        try:
            sql = ''' DELETE FROM emp WHERE  empno = :1 '''

            print(f'1. param empno:{empno}')
            print(f'2. sql:\n{sql}')

            cursor.execute(sql,[empno])
            conn.commit()

            flag =cursor.rowcount
            print(f'flag:{flag}')


        except cx_Oracle.DatabaseError as e:
            # 데이터베이스 관련 예외 처리
            # 오류발생시 롤백
            conn.rollback()
            error = e.args
            print(f'데이터베이스 오류발생, 롤백 수행:{error[0].message}')
        except Exception as e:
            # 데이터베이스 관련 예외 처리
            # 오류발생시 롤백
            conn.rollback()
            print(f'delete 실패:{e}')
        else:
            print('*' * 53)
            print('*delete 성공')
            print('*' * 53)
        finally:
            # 리소스 해제
            try:
                if cursor:
                    cursor.close()

                if conn:
                    conn.close()
            except:
                pass  # 예외 중첩 방지용


        return flag



    def do_insert(self, emp:EmpVO):
        flag = 0 #반영건수

        conn = self.db.connect()  # DB 커넥션
        cursor = conn.cursor()    # cursor
        sql = '''
            INSERT INTO emp (
                empno,
                ename,
                job,
                mgr,
                hiredate,
                sal,
                comm,
                deptno
            ) VALUES ( :1,
                       :2,
                       :3,
                       :4,
                       TO_DATE(:5,'YYYY-MM-DD'),
                       :6,
                       :7,
                       :8 )        
        '''
        try:
            print(f'1. param:{emp}')
            print(f'2. sql:{sql}')

            cursor.execute(sql,(
                emp.empno,
                emp.ename,
                emp.job,
                emp.mgr,
                emp.hiredate,
                emp.sal,
                emp.comm,
                emp.deptno
            )) #SQL+PARAM : 실행
            conn.commit()

            flag=cursor.rowcount
            print(f'3. 반영건수:{flag}')

        except cx_Oracle.DatabaseError as e:
            #데이터베이스 관련 예외 처리
            #오류발생시 롤백
            conn.rollback()
            error=e.args
            print(f'데이터베이스 오류발생, 롤백 수행:{error[0].message}')
        except Exception as e:
            #데이터베이스 관련 예외 처리
            #오류발생시 롤백
            conn.rollback()
            print(f'insert실패:{e}')
        else:
            print('*'*53)
            print('*insert 성공')
            print('*' * 53)
        finally:
            # 리소스 해제
            try:
                if cursor:
                    cursor.close()

                if conn:
                    conn.close()
            except:
                pass  # 예외 중첩 방지용


        return flag




def main():
    """

    """


if __name__ == '__main__':
    main()

