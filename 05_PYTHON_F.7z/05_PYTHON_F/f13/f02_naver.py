from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys


import time
import pyperclip3


def main():

    #크롬 드라이버 경로 설정
    driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))

    #naver 로그인 열기
    url = 'https://nid.naver.com/nidlogin.login?mode=form&url=https://www.naver.com/'
    try:
        driver.get(url)
        time.sleep(3)

        user_id='사용자ID'
        user_passowrd = '비번'



        #아이디 선택
        id_textinput=driver.find_element(By.ID,'id')
        id_textinput.click()
        time.sleep(1)

        #user_id를 클립보드로 복사
        pyperclip3.copy(user_id)  #ctrl+c
        id_textinput.send_keys(Keys.CONTROL,'v') #ctrl+v
        time.sleep(1)


        #비번
        pw_password_input=driver.find_element(By.ID,'pw')
        pw_password_input.click()
        time.sleep(1)

        pyperclip3.copy(user_passowrd) #ctrl+c
        pw_password_input.send_keys(Keys.CONTROL,'v') #ctrl+v
        time.sleep(3)

        #로그인 버튼 클릭:
        login_btn=driver.find_element(By.ID, 'log.login')
        login_btn.click()
        time.sleep(5)

        #스크린샷 저장
        driver.save_screenshot('naver_sel.png')
    except Exception as e:
        print('-'*53)
        print(f'- Exception:{e}')
        print('-' * 53)
    finally:
        #브라우저 닫기
        driver.quit()








if __name__ == '__main__':
    main()
