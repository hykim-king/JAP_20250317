import sys
sys.path.append("D:\\my_python_libs\\mymodule.py")

