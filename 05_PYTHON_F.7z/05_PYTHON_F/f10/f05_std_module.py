import random

def main():
    """
    
    """
    #1~10사이 랜덤 함수
    print(random.randint(1,10))
    print(random.choice(['1호','2호','3호']))


if __name__ == '__main__':
    main()
