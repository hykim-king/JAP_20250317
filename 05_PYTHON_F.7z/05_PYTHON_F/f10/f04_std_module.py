import math
def main():
    """
    
    """
    print(math.sqrt(16)) #4.0
    print(math.pi)

if __name__ == '__main__':
    main()
