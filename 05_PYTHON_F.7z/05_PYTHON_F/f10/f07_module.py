import sys
#sys.path.append("D:\\my_python_libs")

import mymodule

def main():
    """
    현재 상태 path
    sys.path:['D:\\JAP_20250317\\05_PYTHON\\workspace\\f10',
    'D:\\JAP_20250317\\05_PYTHON\\workspace',
    'D:\\JAP_20250317\\05_PYTHON\\workspace\\.venv\\Scripts\\python313.zip',
    'C:\\Users\\user\\AppData\\Local\\Programs\\Python\\Python313\\DLLs',
    'C:\\Users\\user\\AppData\\Local\\Programs\\Python\\Python313\\Lib',
    'C:\\Users\\user\\AppData\\Local\\Programs\\Python\\Python313',
    'D:\\JAP_20250317\\05_PYTHON\\workspace\\.venv',
    'D:\\JAP_20250317\\05_PYTHON\\workspace\\.venv\\Lib\\site-packages']
    """


    print(f'sys.path:{sys.path}')

    print(f'mymodule.add(14,16)->{mymodule.add(14,16)}')

if __name__ == '__main__':
    main()
