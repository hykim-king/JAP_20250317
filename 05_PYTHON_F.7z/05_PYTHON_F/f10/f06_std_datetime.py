from datetime import datetime

def main():
    """
    
    """
    now=datetime.now()

    print(f'datetime.now():{now}')

    print(f'now.year:{now.year}') #년
    print(f'now.hour:{now.hour}') #시간

    #날짜 포맷팅
    formatted=now.strftime("%Y-%m-%d %H:%M:%S")
    print(f'formatted:{formatted}')
if __name__ == '__main__':
    main()
