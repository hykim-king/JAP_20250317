import calcurator

def main():
    """
    
    """
    #30
    print(calcurator.add(14,16))

if __name__ == '__main__':
    main()
