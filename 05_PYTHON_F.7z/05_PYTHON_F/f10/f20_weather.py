import requests
from datetime import datetime

# 기상청 API 설정
API_KEY = "1CGXerQ//aCkEqfaT7Zwz9XIn8Ff2gT6cJkizAreqMalrWWc/c7JiaM6BEBlijfmgGuy/igKjksnMtdbv6ebuQ=="
BASE_URL = "http://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getVilageFcst"
today = datetime.now().strftime("%Y%m%d")  # YYYYMMDD
time = datetime.now().strftime("%H%M")  # 기준 시간 (보통 0200, 0500, 0800 사용 가능)
print(f'time:{time}')
print(f'today:{today}')


def get_weather(nx, ny):
    # 요청 파라미터 설정
    params = {
        "serviceKey": API_KEY,  # 인증키
        "numOfRows": 10,  # 결과 개수
        "pageNo": 1,  # 페이지 번호
        "dataType": "JSON",  # 응답 형식 (JSON 또는 XML)
        "base_date": today,  # 기준 날짜
        "base_time": time,  # 기준 시간
        "nx": nx,  # 격자 X 좌표
        "ny": ny  # 격자 Y 좌표
    }
    response = requests.get(BASE_URL, params=params)
    print(f'response:{response.text}')
    if response.status_code == 200:
        data = response.json()
        items = data["response"]["body"]["items"]["item"]
        # 출력 예제

        for item in items:
            print(f"예보 시간: {item['fcstTime']}, 항목: {item['category']}, 값: {item['fcstValue']}")
            #print(interpret_weather_data(item['category'], item['fcstValue']))
    else:
        print(f"기상청 데이터를 가져올 수 없습니다. 오류 코드: {response.status_code}")

    print(f'response:{response.status_code}')


def interpret_weather_data(category, value):
    mapping = {
        "POP": f"강수확률 {value}%",
        "PTY": {
            "0": "강수 없음",
            "1": "비",
            "2": "비/눈",
            "3": "눈",
            "4": "소나기",
            "5": "빗방울",
            "6": "빗방울/눈날림",
            "7": "눈날림",
        }.get(value, "알 수 없음"),
        "SKY": {
            "1": "맑음",
            "3": "구름 많음",
            "4": "흐림",
        }.get(value, "알 수 없음"),
        "TMP": f"기온 {value}℃",
        "REH": f"습도 {value}%",
        "WSD": f"풍속 {value}m/s",
        "VEC": f"풍향 {value}°",
    }

    return mapping.get(category, f"{category}: {value}")


def main():
    '''

    '''
    get_weather(nx=60, ny=127)


if __name__ == '__main__':
    main()
