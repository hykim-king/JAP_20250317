from openpyxl import load_workbook


def main():
    '''

    '''

    # Excel 파일 열기
    wb = load_workbook("example.xlsx")
    ws = wb.active

    # 데이터 읽기
    for row in ws.iter_rows(values_only=True):  # values_only=True로 값만 읽음
        print(row)
    # 출력:
    ('이름', '나이')
    ('철수', 22)
    ('영희', 18)


if __name__ == '__main__':
    main()