import requests
from bs4 import BeautifulSoup

def google_crawling():
    url = 'https://www.google.com/'

    response=requests.get(url)

    if response.status_code == 200:
        print(f'접속 성공:{response.status_code}')
        print(f'response.text:{response.text}')
    else:
        print(f'접속 실패:{response.status_code}')

def main():
    """
    
    """
    google_crawling()
    



if __name__ == '__main__':
    main()
