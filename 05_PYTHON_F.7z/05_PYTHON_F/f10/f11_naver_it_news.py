import requests
from bs4 import BeautifulSoup
from requests.exceptions import ConnectionError

def naver_it_news():
    print(f'naver_it_news')

    url = 'https://news.naver.com/section/105'

    try:
       response=requests.get(url)

       if response.status_code == 200:
           html=response.text
           #print(f'html:\n{html}')

           bs = BeautifulSoup(html,'html.parser')

           #뉴스 제목: strong->html tag
           #.sa_text_strong: class
           new_titles=bs.select('strong.sa_text_strong')
           print(f'new_titles:{len(new_titles)}')

           for title  in new_titles:
               print(f'{title.text}')

           #뉴스 상세 링크: div.sa_text a sa_text_title (제목 상세)
           news_links = bs.select('div.sa_text a.sa_text_title')
           print(f'news_links:{len(news_links)}')
           for link in news_links:
               print(f'link:href:{link['href']}')



       else:
           print(f'접속실패:{response.status_code}')


    except ConnectionError as e:
        print('-'*80)
        print(f'ConnectionError:{e}')
        print('-' * 80)
    else:
        print('*'*80)
        print(f'정상종료')
        print('*' * 80)
    finally:
        print('='*80)
        print(f'항상 수행')
        print('=' * 80)

def main():
    """
    
    """
    naver_it_news()

if __name__ == '__main__':
    main()
