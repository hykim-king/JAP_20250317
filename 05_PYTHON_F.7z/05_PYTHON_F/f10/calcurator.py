def add(a,b):
    '''
    더하기
    :param a:
    :param b:
    :return:a+b
    '''

    return a+b

def substract(a,b):
    '''
    빼기
    :param a:
    :param b:
    :return: a-b
    '''
    return a-b

def multiply(a,b):
    return a * b

def divide(a,b):
    if b !=0:
        return a / b
    else:
        return "0으로 나눌수 없습니다."


