import calcurator as calc

def main():
    """
    
    """
    print(calc.multiply(14,2))

if __name__ == '__main__':
    main()
