from openpyxl import Workbook

# 새 워크북 생성
wb = Workbook()


# 기본 시트 선택
ws = wb.active
ws.title = "ExampleSheet"  # 시트 이름 변경


# 데이터 쓰기
ws['A1'] = "이름"
ws['B1'] = "나이"
ws.append(["철수", 22])  # 행 추가
ws.append(["영희", 18])


# 파일 저장
wb.save("example.xlsx")
print("Excel 파일이 저장되었습니다.")