from openpyxl import Workbook
import datetime


def main():
    """
    
    """
    wb = Workbook()

    ws=wb.active

    ws['A1'] = 14
    ws['A2'] =datetime.datetime.now()
    ws.append([1,2,3])


    wb.save('pcwk.xlsx')

if __name__ == '__main__':
    main()
