from calcurator import add, divide

def main():
    """
    
    """
    print(add(14,16))
    print(divide(14, 2))

if __name__ == '__main__':
    main()
