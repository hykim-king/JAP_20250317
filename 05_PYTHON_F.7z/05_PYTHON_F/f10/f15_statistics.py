import math
import statistics

def main():
    """
    
    """
    data = [10, 20, 30, 30, 40, 50, 30]
    mean = statistics.mean(data)

    print(f'합계:{sum(data)}')
    print(f'개수:{len(data)}')
    print(f'평균:{mean}')

    var=statistics.variance(data)
    std_dev = statistics.stdev(data)

    print(f'분산:{var},분산_sqrt:{math.sqrt(var):.2f}')
    print(f'표준편차:{std_dev:.2f}')

    mode_val = statistics.mode (data)
    print(f'최빈값:{mode_val}') #최빈값:30



if __name__ == '__main__':
    main()
