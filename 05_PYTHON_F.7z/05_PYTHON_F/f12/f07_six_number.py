import random
import schedule
import time

def lotto():
    '''
    1~45사이 중보되지 않는 숫자 6개 출력
    :return:
    '''
    print(f'lotto')

    result = []
    while len(result) < 6:
        num = random.randint(1,45)

        if num not in result: # 중복 숫자 뽑기 방지
            result.append(num)

    #print(f'result:{result}')
    result.sort()
    print(f'result asc:{result}')

def main():
    """
    
    """
    lotto()
    # 매 1분 마다 실행
    schedule.every(1).minutes.do(lotto)

    #루프를 돌면서 작업 실행 여부 확인
    while True:
        schedule.run_pending()
        time.sleep(1) # 1초마다 확인


if __name__ == '__main__':
    main()
