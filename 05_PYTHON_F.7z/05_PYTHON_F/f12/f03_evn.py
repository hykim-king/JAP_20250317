import os
from dotenv import load_dotenv

def main():
    """
    
    """
    #현재 실행 파일 기준으로 .env 파일 읽음
    load_dotenv(dotenv_path="../.env")

    CLIENT_ID =os.getenv('CLIENT_ID')
    CLIENT_SECRET = os.getenv('CLIENT_SECRET')


    print(f'CLIENT_ID:{CLIENT_ID}')
    print(f'CLIENT_SECRET:{CLIENT_SECRET}')

if __name__ == '__main__':
    main()
