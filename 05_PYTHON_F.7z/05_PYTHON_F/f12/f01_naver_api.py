import os
from dotenv import load_dotenv


import sys

import urllib.parse
import urllib.request

import json


def json_naver_blog():
    print(f'json_naver_blog')

    #.env 파일 로드
    load_dotenv(dotenv_path="../.env")

    clientId = os.getenv('CLIENT_ID')
    clientSecret = os.getenv('CLIENT_SECRET')

    #print(f'clientId:{clientId}')
    #print(f'clientSecret:{clientSecret}')

    try:
        #검색어
        search_word = input('블로그 검색어를 입력 하세요>')
        print(f'search_word:{search_word}')

        #검색어 UTF-8로 인코딩되어야 합니다.
        search_word= urllib.parse.quote(search_word,encoding='utf-8')
        print(f'url_encoding_search_word:{search_word}')

        url = 'https://openapi.naver.com/v1/search/blog.json?query='+search_word
        print(f'url:{url}')

        request=urllib.request.Request(url)
        #clientID, clientSecret설정
        request.add_header('X-Naver-Client-Id',clientId)
        request.add_header('X-Naver-Client-Secret', clientSecret)

        #요청
        response=urllib.request.urlopen(request)

        print(f'response.getcode:{response.getcode()}')

        if 200 == response.getcode(): #성공 코드

            responseBody=response.read()
            print(f'responseBody:{responseBody.decode('utf-8')}')
            return responseBody.decode('utf-8')
        else:
            print(f'접속 실패:{response.getcode()}')


    except ConnectionError as e:
        print('-'*54)
        print(f'ConnectionError:{e}')
        print('-'*54)
    else:
        print('*'*54)
        print(f'정상 종료!')
        print('*'*54)
    finally:
        print(f'finally---')

def main():
    """
    
    """
    data =json_naver_blog()
    print(f'data:{type(data)}') #data:<class 'str'>
    dicObject=json.loads(data)

    print(f'dicObject:{type(dicObject)}')
    print(f'dicObject:\n{dicObject}')

    for item in dicObject.get('items'):
        print(f'item[title]:{item['title']} \t {item['description']}')


if __name__ == '__main__':
    main()
