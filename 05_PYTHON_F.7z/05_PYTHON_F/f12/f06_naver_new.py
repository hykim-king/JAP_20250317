import schedule
import time
import os
from dotenv import load_dotenv
import urllib.parse
import urllib.request

import json

def naver_news():

    print(f'naver_news')
    clientId = os.getenv('CLIENT_ID')
    clientSecret = os.getenv('CLIENT_SECRET')
    print("Client ID:", clientId)
    print("Client Secret:", clientSecret)
    try:
        # 검색어
        search_word = input('블로그 검색어를 입력 하세요>')
        print(f'search_word:{search_word}')

        #검색어 UTF-8로 인코딩되어야 합니다.
        search_word= urllib.parse.quote(search_word,encoding='utf-8')
        print(f'url_encoding_search_word:{search_word}')

        url = 'https://openapi.naver.com/v1/search/news.json?query='+search_word
        print(f'url:{url}')

        request=urllib.request.Request(url)
        #clientID, clientSecret설정
        request.add_header('X-Naver-Client-Id',clientId)
        request.add_header('X-Naver-Client-Secret', clientSecret)

        #요청
        response=urllib.request.urlopen(request)

        print(f'response.getcode:{response.getcode()}')

        if 200 == response.getcode(): #성공 코드

            responseBody=response.read()
            print(f'responseBody:{responseBody.decode('utf-8')}')
            return responseBody.decode('utf-8')
        else:
            print(f'접속 실패:{response.getcode()}')


    except ConnectionError as e:
        print('-'*54)
        print(f'ConnectionError:{e}')
        print('-'*54)
    else:
        print('*'*54)
        print(f'정상 종료!')
        print('*'*54)
    finally:
        print(f'finally---')



def main():
    """
    
    """
    #.env 파일 로드
    load_dotenv()
    load_dotenv(dotenv_path="../.env")

    # 매일 특정 시간 실행
    schedule.every().day.at("12:27").do(naver_news)


    # 루프를 돌면서 작업 실행 여부 확인
    while True:
        schedule.run_pending()
        time.sleep(1)  # 1초마다 확인

if __name__ == '__main__':
    main()
