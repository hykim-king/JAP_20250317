import cx_Oracle

def main():


    try:
        conn = None
        cursor = None

        #데이터베이스 연결 시도
        conn=cx_Oracle.connect('scott','pcwk','192.168.100.30:1522/XE')

        print(f'conn:{conn}')

        #SQL실행
        cursor=conn.cursor()
        print(f'cursor:{cursor}')

        sql = 'SELECT * FROM emp'
        print(f'sql:{sql}')
        cursor.execute(sql)

        for row in cursor:
            print(row)


    except cx_Oracle.DatabaseError as e:
        # 데이터베이스 관련 예외 처리
        error,=e.args
        print(f'Oracle 데이터베이스 오류:{error.message}')
    except Exception as e:
        print(f'Exception:{e}')
    finally:
        #리소스 해제
        try:
            if cursor:
                cursor.close()

            if conn:
                conn.close()
        except:
            pass # 예외 중첩 방지용


if __name__ == '__main__':
    main()
