from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
import time

def main():
    """
    
    """
    # 크롬 드라이버 경로 설정
    driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))


    # 구글 홈페이지 열기
    driver.get('https://www.google.com')
    time.sleep(5)

    # 구글 검색창에 'Python' 입력 후 검색
    search_box = driver.find_element(By.NAME, "q")

    search_box.send_keys('Python')
    time.sleep(5)
    search_box.submit()

    # 페이지 제목 출력
    print("Page title:", driver.title)

    # 스크린샷 저장
    driver.save_screenshot('screenshot.png')

    # 브라우저 닫기
    driver.quit()
if __name__ == '__main__':
    main()
