# 전체 패키지 불러오기
# import mypackage.calc
# import mypackage.stats
#
#
# print(f'{mypackage.calc.add(14,16)}')  #30
# print(f'{mypackage.stats.average([1,2,3,4,5])}') #3.0

#특정 모듈 불러오기
# from mypackage import calc,stats
#
# print(f'{calc.add(14,16)}')
# print(f'{stats.average([1,2,3,4,5])}')

from mypackage import *

print(f'{stats}')