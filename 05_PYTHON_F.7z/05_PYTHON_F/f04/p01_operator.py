def main():
    """
    
    """
    a = 10
    b = 3
    result = a ** b +a
    result = b-a % a
    print(result)

if __name__ == '__main__':
    main()
