def main():
    """
    
    """
    multiline = ''' 이것은 여러줄
    에 걸처 작성되는 문자열 
    입니다.
    '''
    print(f'multiline:{multiline}')
    ############################################
    print("#"*53)

    new_line = 'Hello\nWorld'
    print(f'new_line:{new_line}')
    ############################################
    print("#" * 53)

    binary = 0b1010
    print(f'binary:{binary}')

    octal =0o12
    print(f'octal:{octal}')

    hexadecimal = 0xA
    print(f'hexadecimal:{hexadecimal}')





if __name__ == '__main__':
    main()
