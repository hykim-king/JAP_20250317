def main():
    """
    strip()	양옆 공백 또는 지정된 문자 제거
    replace()	특정 문자열을 다른 문자열로 교체
    find()	부분 문자열의 시작 인덱스를 반환
    count()	부분 문자열이 나타나는 횟수 반환
    startswith()	접두사가 일치하는지 확인
    endswith()	접미사가 일치하는지 확인
    split()	구분자를 기준으로 문자열을 나눔
    len()	문자열의 길이 반환
    """

    #len()	문자열의 길이 반환
    my_string = 'Hello, python'
    print(f'my_string:{my_string}')

    str_length = len(my_string)
    print(f'str_length:{str_length}')
    #######################################
    print('#'*53)

    #strip()	양옆 공백 또는 지정된 문자 제거
    padded_text = ' Hello, Python! '
    print(f'padded_text:{padded_text}')
    print(f'strip:{padded_text.strip()}')
    #######################################
    print('#'*53)

    #replace()	특정 문자열을 다른 문자열로 교체
    original_text = 'Hello, Python!'
    print(f'original_text:{original_text}')

    replace_text=original_text.replace('Python','World')
    print(f'replace_text:{replace_text}')
    #######################################
    print('#'*53)


    #split()	구분자를 기준으로 문자열을 나눔
    sentence = "오늘은 즐거운 목요일 4일전 입니다."
    words=sentence.split()

    print(f'words{words}, {type(words)}')


    #find()	부분 문자열의 시작 인덱스를 반환
    full_text = "f01_string.py"

    index=full_text.find(".")
    print(f'index:{index}')

    endswith_text = full_text.endswith("py")
    print(f'full_text:{full_text}')
    print(f'endswith_text:{endswith_text}')



if __name__ == '__main__':
    main()
