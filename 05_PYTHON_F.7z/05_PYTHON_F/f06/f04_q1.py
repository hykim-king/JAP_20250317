def main():
    """
    
    """
    text = "apple banana apple orange banana apple"

    words=text.split()

    print(f'words:{words}')

    #{'apple':3,'banana':2,'orange':1}
    word_count = {}

    for word in words:
        word_count[word] = word_count.get(word,0)+1

    print(f'word_count:{word_count}')



if __name__ == '__main__':
    main()
