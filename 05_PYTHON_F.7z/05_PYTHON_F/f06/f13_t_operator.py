def main():
    """
    
    """

    score = 88
    result = '합격' if score>60 else '불합격'
    print(f'result:{result}')

    print('#'*53)
    #####################################################

    fruits = ['복숭아','바나나','체리']
    print(f'fruits:{fruits}, type:{type(fruits)}')

    if '복숭아' in fruits:
        print(f'리스트에 복숭아가 있습니다.')

    if '사과' not in fruits:
        print(f'사과는 리스트에 없습니다.')


    print('#'*53)
    #####################################################
    age =25
    is_employed = True

    if age > 18 and is_employed:
        print('성인이며 직업이 있습니다.')

    if not is_employed:
        print('직업이 있습니다.')



if __name__ == '__main__':
    main()
