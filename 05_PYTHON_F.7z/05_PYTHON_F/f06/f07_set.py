def main():
    """
    
    """
    s01 = {1,2,2,3}

    #s01:{1, 2, 3}, type:<class 'set'>
    print(f's01:{s01}, type:{type(s01)}')
    #####################################################
    print('#'*53)

    #set()
    s02=set([1,2,2,3,3,4,5])
    #s02:{1, 2, 3, 4, 5}, type:<class 'set'>
    print(f's02:{s02}, type:{type(s02)}')

    #빈 집합은 반드시 set()
    # 빈 집합은 반드시 set()함수로 생성해야 합니다.
    # {}는 딕셔너리로 인식 됩니다.
    empty_set = set()
    dic_empty = {}
    print(f'empty_set type:{type(empty_set)}')
    print(f'dic_empty type:{type(dic_empty)}')

    #문자열을 set()
    s03=set('Hello')
    #s03:{'l', 'e', 'H', 'o'}
    print(f's03:{s03}')


if __name__ == '__main__':
    main()
