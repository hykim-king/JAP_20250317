def main():
    """
    
    """
    #set자료형에 저장된 값을 인덱싱으로 접근
    s01=set([14,16,19])

    print(f's01:{s01},type:{type(s01)}')

    #set -> list
    tmp_list = list(s01)
    print(f'tmp_list:{tmp_list},type:{type(tmp_list)}')

    tmp_list[0]=15
    print(f'tmp_list:{tmp_list},type:{type(tmp_list)}')

    #list -> set
    s01=set(tmp_list)
    print(f's01:{s01},type:{type(s01)}')

    #set -> tuple
    tmp_tuple=tuple(s01)
    print(f'tmp_tuple[2]:{tmp_tuple[2]}')

    # tuple -> set
    s01=set(tmp_tuple)
    print(f's01:{s01},type:{type(s01)}')







if __name__ == '__main__':
    main()
