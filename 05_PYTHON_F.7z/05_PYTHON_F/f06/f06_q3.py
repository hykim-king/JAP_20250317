def main():
    """
    
    """
    scores = {"이상무": 85, "영희":92,"철수":78, "바둑이":95}
    #90 점 이상인 학생들만 선택
    high_score = {}
    for name,score in scores.items():
        if(score>=90):
            high_score[name]=score
    # high_score: {'영희': 92, '바둑이': 95}
    print(f'high_score:{high_score}')

    #python
    p_high_score={name:score for name, score in scores.items() if score>=90}
    print(f'p_high_score:{p_high_score}')


if __name__ == '__main__':
    main()
