def main():
    """
    
    """
    # 추첨 결과: [3, 5, 12, 17, 23, 38]
    # 사용자 입력 번호: [5, 8, 12, 13, 23, 42]

    drawn = set([3, 5, 12, 17, 23, 38])
    user  = set([5, 8, 12, 13, 23, 42])

    matched = drawn & user

    print(f'맞은 번호: {matched}, 개수:{len(matched)}')



if __name__ == '__main__':
    main()
