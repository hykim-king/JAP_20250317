def main():
    """
    
    """
    person = {'name':'영희','age':8}

    #값 접근 : person['name']:영희
    print(f'person[\'name\']:{person['name']}')


    #안전한 값 접근 : get()함수
    print(person.get('name1','Not found'))
    #####################################################
    print('#'*53)

    #값 추가
    person['city']='Seoul' # 새로운 키-값 추가
    print(f'person:{person}')

    #리스트를 value로 추가
    person['items']=[1,2,3]

    # 값 수정
    person['age'] = 21
    print(f'person:{person}')
    #####################################################
    print('#'*53)

    #특정 키 삭제
    del person['city']
    print(f'person:{person}')

    #pop() 사용
    age=person.pop('age')
    print(f'age:{age}')
    print(f'person:{person}')

    #전체 삭제
    person.clear()
    print(f'person:{person}')







if __name__ == '__main__':
    main()
