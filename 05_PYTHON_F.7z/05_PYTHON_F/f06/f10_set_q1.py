def main():
    """
    
    """
    cafe_A = {'철수', '영희', '민수', '지수', '영철'}
    cafe_B = {'민수', '지수', '정우', '하영'}

    #'1. 두 카페 모두 가입한 사람은?'

    print(f'type:{type(cafe_A)}')
    print(f' cafe_A & cafe_B: {cafe_A & cafe_B}')

    # 2. A 카페만 가입한 사람은?
    print(f' cafe_A - cafe_B: {cafe_A - cafe_B}')

    # 3. 두 카페 중 한 곳에만 가입한 사람은?
    print(f' cafe_A ^ cafe_B: {cafe_A ^ cafe_B}')


if __name__ == '__main__':
    main()
