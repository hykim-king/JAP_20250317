def main():
    """
    
    """
    person = {'name':'영희','age':8,'city':'Seoul'}
    print(f'person:{person}')

    #keys() : 모든 키 조회
    print(f'person.keys():{person.keys()}')

    #반복문
    for key in person.keys():
        print(f'key:{key},value:{person[key]}')


    #values() : 모든 값 조회
    print(f'person.values():{person.values()}')

    #items()
    #person.items():dict_items([('name', '영희'), ('age', 8), ('city', 'Seoul')])
    print(f'person.items():{person.items()}')

    #해당 key가 딕셔너리에 있는지 확인
    is_name_in = 'name' in person
    print(f'is_name_in:{is_name_in}')


if __name__ == '__main__':
    main()
