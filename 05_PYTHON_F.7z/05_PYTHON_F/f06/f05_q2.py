def add(x,y):
    return x + y

def subtract(x,y):
    return x - y

def multiply(x,y):
    return x * y


def main():
    """
    
    """

    #함수를 딕셔너리에 할당
    operation = {
        "add": add,
        "subtract":subtract,
        "multiply":multiply
    }


    result=operation['add'](14,16)
    print(f'result:{result}')

    result=operation['multiply'](14,16)
    print(f'result:{result}')


if __name__ == '__main__':
    main()
