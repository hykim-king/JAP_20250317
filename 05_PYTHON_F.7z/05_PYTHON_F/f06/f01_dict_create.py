def main():
    """
    
    """
    empty_dict= {}

    print(f'empty_dict:{empty_dict}')

    person = {'name':"이상무",'age':22,'city':'seoul'}
    print(f'person:{person}')

    ###################################################
    new_person=dict(name='이상무',age=21,city='Busan')
    print(f'new_person: {new_person}')
    #new_person: {'name': '이상무', 'age': 21, 'city': 'Busan'}
    ###################################################



if __name__ == '__main__':
    main()
