def main():
    """
    
    """

    age = 18

    if age >=18:
       print('성인 입니다.')
    else:
       print('성인이 아닙니다.')

    #################################
    score = 85
    if score>=90:
        print('A')
    elif score>=80:
        print('B')
    elif score>=70:
        print('C')
    elif score >= 70:
        print('D')
    else:
        print('F')

    #################################
    age = 20
    is_student = True

    if age >=18:
        #pass : 빈 코드 작성
        if is_student:
            print('성인이면 학생 입니다..')
        else:
            print('성인이면 학생이 아닙니다.')
    else:
        print('미성년자')






if __name__ == '__main__':
    main()
