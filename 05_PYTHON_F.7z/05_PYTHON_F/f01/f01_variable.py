def main():
    """
    
    """
    print("변수란")




if __name__ == '__main__':
    main()
