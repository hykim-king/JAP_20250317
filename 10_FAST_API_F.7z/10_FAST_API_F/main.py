from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import pickle
import numpy as np
from fastapi.middleware.cors import CORSMiddleware



# 1) 입력 스키마 (Iris 특징 4개)
class IrisInput(BaseModel):
    sepal_length: float = Field(..., description="꽃받침 길이")
    sepal_width:  float = Field(..., description="꽃받침 너비")
    petal_length: float = Field(..., description="꽃잎 길이")
    petal_width:  float = Field(..., description="꽃잎 너비")

# 2) 앱 생성
app = FastAPI(title="Iris FastAPI", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 배포 시 도메인 제한 권장
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# 3) 모델 로드 (앱 시작 시 1회)
@app.on_event("startup")
def load_model():
    global model
    try:
        with open("model.pkl", "rb") as f:
            model = pickle.load(f)
    except Exception as e:
        raise RuntimeError(f"모델 로드 실패: {e}")

# 4) 헬스체크
@app.get("/health")
def health():
    return {"status": "ok"}

# 5) 예측 엔드포인트
@app.post("/iris_predict")
def predict(item: IrisInput):
    try:
        X = np.array([[item.sepal_length, item.sepal_width,
                       item.petal_length, item.petal_width]])
        print(f'X:{X}')
        pred = model.predict(X)[0]                # 품종 라벨 (예: setosa)
        proba = getattr(model, "predict_proba", None)
        if callable(proba):
            probs = model.predict_proba(X)[0].tolist()
        else:
            probs = None

        print(f'pred:{str(pred)}')
        return {"prediction": str(pred), "probabilities": probs}
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"예측 실패: {e}")



if __name__ == '__main__':
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)