from fastapi import FastAPI

app = FastAPI()

@app.get(path="/")
def hello():
    print('-'*80)
    print(f'hello()')
    print('-' * 80)

    return {'message': 'Hello, FastAPI'}
