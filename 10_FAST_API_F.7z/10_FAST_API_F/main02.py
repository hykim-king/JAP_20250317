from fastapi import FastAPI

app = FastAPI(title='PCWK 웹서비스'
, description='FastAPI hello'
, version="1.0")

@app.get(path="/hello"
, summary='Hello,world!를 출력 합니다.'
, description='이 API는 Hello, 를 출력')
def hello():
    print(f'hello()')
    return {"message":'Hello FastAPI!'}


@app.get("/hello/{name}")
def read_item(name: str):
    print(f'read_item()')
    print(f'name:{name}')
    return {"greeting": f"Hello, {name}!"}




if __name__ == '__main__':
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)

