COL employees FOR A60
SELECT deptno,
       LISTAGG( ename || '(' || sal ||')'  ,',' ON OVERFLOW TRUNCATE '...') WITHIN GROUP(ORDER BY sal DESC) AS employees
  FROM emp
 GROUP BY  deptno
 ORDER BY  deptno
; 

