SELECT * FROM emp@remote_link;
--SELECT * FROM sales@remote_link;