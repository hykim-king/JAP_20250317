COL "XMLELEMENT" FOR A120

SELECT deptno,
       SUBSTR( XMLAGG( XMLELEMENT("name",',',ename) ORDER BY ename )
        .EXTRACT('//text()').getClobVal(),2)  AS "XMLELEMENT"
  FROM emp
 GROUP BY deptno
 ;
 
     DEPTNO XMLELEMENT
---------- --------------------------------------------------------
        10 CLARK,KING,MILLER
        20 FORD,JONES,SCOTT,SMITH
        30 ALLEN,BLAKE,JAMES,TURNER,WARD