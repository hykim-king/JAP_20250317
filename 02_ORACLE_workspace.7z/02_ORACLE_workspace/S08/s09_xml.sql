COL "XMLELEMENT" FOR A50
SELECT deptno,
       XMLAGG( XMLELEMENT("US.PR",',', ename) ORDER BY ename) "XMLELEMENT"
  FROM emp
 GROUP BY deptno  
; 