SELECT grade,deptno1,COUNT(*) AS grade_cnt
  FROM student
 GROUP BY GROUPING SETS(grade,deptno1)
 ORDER BY grade,deptno1
; 