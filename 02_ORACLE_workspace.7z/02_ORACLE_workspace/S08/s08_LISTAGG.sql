
COL employees FOR A50
SELECT deptno,
       LISTAGG( ename,',') WITHIN GROUP(ORDER BY ename DESC) AS employees
  FROM emp
 GROUP BY  deptno
 ORDER BY  deptno
;
--10 CLARK,KING,MILLER
--20 FORD,JONES,SCOTT,SMITH
--30 
