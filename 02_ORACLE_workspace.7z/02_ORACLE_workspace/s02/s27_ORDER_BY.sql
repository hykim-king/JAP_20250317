SELECT empno,
       ename,
	   sal
  FROM emp
 ORDER BY 3 DESC --3: sal
;