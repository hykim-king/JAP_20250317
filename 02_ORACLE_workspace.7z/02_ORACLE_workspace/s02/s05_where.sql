SELECT ename,
       hiredate
  FROM emp
 WHERE hiredate = '81/04/02' 
;  