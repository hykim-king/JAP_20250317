SELECT ename
  FROM emp
 WHERE ename LIKE '_L%' 
;  