col sal_after_tax for $9,999.00
SELECT ename,
       sal,
	   sal*0.9 AS sal_after_tax
  FROM emp
; 