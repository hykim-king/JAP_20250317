SELECT ename
  FROM emp
 WHERE ename LIKE '%T' 
;  