SELECT ename,
       empno,
	   sal
  FROM emp
 WHERE  ename = 'ward'
;  