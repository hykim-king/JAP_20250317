SELECT empno,
       ename,
	   sal,
	   comm
  FROM emp
 ORDER BY comm DESC NULLS LAST
; 