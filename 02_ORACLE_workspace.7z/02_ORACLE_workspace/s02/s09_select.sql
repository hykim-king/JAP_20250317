--빈 줄 → SQL 명령 끝났다고 오해함 → 실행 시도
--FROM emp는 새로운 명령어로 인식되며, 이건 유효한 명령이 아니므로 오류 발생
SELECT ename|| ' is a ' ||job AS  description

  FROM emp
;  