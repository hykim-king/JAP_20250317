SELECT empno,
       ename,
	   comm
  FROM emp
 WHERE comm IS NULL
;  