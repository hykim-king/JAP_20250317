SELECT ename,
       sal
  FROM emp
 WHERE sal BETWEEN 1000 AND 3000
; 