SELECT empno,
       ename
  FROM emp
 WHERE empno = 7902 
;  