SELECT ename,
       sal
  FROM emp
 WHERE sal >= 1000 
   AND sal <= 3000
;