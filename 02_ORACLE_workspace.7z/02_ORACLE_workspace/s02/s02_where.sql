COL ename FOR A10
COL sal   FOR $999,999

SELECT empno,
       ename,
	   sal
  FROM emp
 WHERE sal < 1000 
;  
  