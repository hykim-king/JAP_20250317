-- ����
SELECT empno, 
       ename,      
	   job, 
	   mgr 
  FROM emp
 WHERE job = 'MANAGER';