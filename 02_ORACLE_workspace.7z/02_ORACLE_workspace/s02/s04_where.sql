SELECT ename,
       empno,
	   sal
  FROM emp
 WHERE  ename >= 'K'
; 