SELECT empno,
       ename,
	   sal
  FROM emp
 WHERE ename = '&name' 
; 