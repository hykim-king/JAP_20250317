--col name for a21
--SELECT name,
--       profno
--  FROM student
--;  
--
--SELECT profno,
--       name
--  FROM professor
--;  
col student_name for a21
col prof_name    for a21

SELECT t1.name AS student_name,
       t2.name AS prof_name
  FROM student t1, professor t2
 WHERE t1.profno =  t2.profno
; 
