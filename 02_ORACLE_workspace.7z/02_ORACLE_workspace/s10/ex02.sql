COL name FOR A16
COL pay FOR A16
COL position FOR A22
COL "Low Pay" FOR A16
COL "High Pay"  FOR A16
SELECT  t1.name
        ,TO_CHAR(t1.pay,'9,999,999,999') AS pay
        ,t1.position
        ,TO_CHAR(t2.s_pay ,'9,999,999,999') AS "Low Pay"
        ,TO_CHAR(t2.e_pay ,'9,999,999,999') AS "High Pay" 
  FROM emp2 t1, p_grade t2
 WHERE t1.position = t2.position
;  