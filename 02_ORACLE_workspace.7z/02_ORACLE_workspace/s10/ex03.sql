COL name          FOR A17
COL curr_position FOR A22
COL be_position   FOR A22

SELECT  t1.name
        ,t1.position                          AS curr_position
        ,TRUNC((SYSDATE - t1.birthday)/365)   AS AGE
        ,t2.position                          AS be_position
  FROM emp2 t1, p_grade t2
 WHERE TRUNC((SYSDATE - t1.birthday)/365) BETWEEN t2.s_age AND t2.e_age
; 