
col stud_name for a17
col dname     for a37


--[ORACLE JOIN]
SELECT t1.name AS stud_name,
       t1.deptno1, 
       t2.dname
  FROM student t1, department t2
 WHERE t1.deptno1 = t2.deptno 
; 

--[ANSI JOIN]
SELECT t1.name AS stud_name,
       t1.deptno1, 
       t2.dname
  FROM student t1 
  JOIN department t2 ON t1.deptno1 = t2.deptno 
; 