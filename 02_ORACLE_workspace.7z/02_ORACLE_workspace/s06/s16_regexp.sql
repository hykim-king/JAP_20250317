SELECT text
  FROM t_reg
 WHERE NOT REGEXP_LIKE( text,'[a-zA-Z0-9]')
; 
