--4 172.61.186.2
--5 172.61.168.2
SELECT *
  FROM t_reg2
 WHERE REGEXP_LIKE(ip,'^[172]{3}\.[61]{2}\.[0-9]{3}\.')
;
 

