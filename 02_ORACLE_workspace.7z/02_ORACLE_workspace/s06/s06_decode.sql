COL name FOR A19
SELECT name,
       jumin,
	   DECODE(SUBSTR(jumin,7,1),
	          1,'MAN',
			  3,'MAN',
			  2,'WOMAN',
			  4,'WOMAN')AS GENDER
  FROM student
 WHERE deptno1 = 101  
;  