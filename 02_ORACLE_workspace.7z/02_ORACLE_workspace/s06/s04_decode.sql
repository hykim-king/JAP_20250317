--IF(DEPTNO == 101){
--   IF(NAME== Audie Murphy) 'BEST!'
--   ELSE 'GOOD!'
--}ELSE{
--   NULL
--}


SELECT name,     
       deptno,
       DECODE(deptno,
	          101,DECODE(name,
			            'Audie Murphy','BEST!'
			     		,'GOOD!'),
			  NULL) AS ETC	   
  FROM professor
;  