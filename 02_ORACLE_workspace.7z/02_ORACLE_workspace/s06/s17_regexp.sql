col email for a50
SELECT email
  FROM professor
 WHERE REGEXP_LIKE(email,'[A-Za-z0-9._%+1]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')
;

