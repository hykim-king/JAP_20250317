--IF(DEPTNO == 101){
--   IF(NAME== Audie Murphy) 'BEST!'
--   ELSE 'GOOD!'
--}ELSE{
--   'N/A'
--}


SELECT name,     
       deptno,
       DECODE(deptno,
	          101,DECODE(name,
			            'Audie Murphy','BEST!'
			     		,'GOOD!'),
			  'N/A') AS ETC	   
  FROM professor
;  