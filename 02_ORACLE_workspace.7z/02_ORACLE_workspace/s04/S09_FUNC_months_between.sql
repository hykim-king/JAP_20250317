SELECT MONTHS_BETWEEN( TO_DATE('2025-02-28', 'YYYY-MM-DD'),
                       TO_DATE('2025-01-31', 'YYYY-MM-DD') ) AS diff		
  FROM dual;