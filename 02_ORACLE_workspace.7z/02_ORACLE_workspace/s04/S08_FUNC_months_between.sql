
--SELECT MONTHS_BETWEEN( TO_DATE('2025-03-17', 'YYYY-MM-DD'),
--                       TO_DATE('2025-05-17', 'YYYY-MM-DD') ) AS diff,
--       MONTHS_BETWEEN( TO_DATE('2025-05-17', 'YYYY-MM-DD'),
--                       TO_DATE('2025-03-17', 'YYYY-MM-DD') ) AS diff					   
--  FROM dual;
  
--�ݴ�  
SELECT MONTHS_BETWEEN( TO_DATE('2025-05-15', 'YYYY-MM-DD'),
                       TO_DATE('2025-05-01', 'YYYY-MM-DD') ) AS diff		
  FROM dual;