SELECT ADD_MONTHS( SYSDATE, 4) AS after_4_months,
       ADD_MONTHS( SYSDATE, -2) AS before_2_months
  FROM dual
;  
