SELECT SYSDATE AS today,
       ROUND(SYSDATE) AS rounded_day
  FROM dual;