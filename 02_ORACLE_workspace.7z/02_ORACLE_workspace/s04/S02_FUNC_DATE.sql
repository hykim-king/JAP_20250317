
SELECT ename,
       sysdate - hiredate as "�ټ���"
  FROM emp
 WHERE deptno = 10; 