col region  for a10
col product for a10

SELECT region, product, SUM(amount) AS total_amount
  FROM sales
GROUP BY ROLLUP(region, product)
ORDER BY region, product
;