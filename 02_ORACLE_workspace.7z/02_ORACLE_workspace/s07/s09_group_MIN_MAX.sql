SELECT MIN(ename),
       MAX(ename)
 FROM emp
; 