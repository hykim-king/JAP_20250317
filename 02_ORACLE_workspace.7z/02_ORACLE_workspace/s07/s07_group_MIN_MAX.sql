SELECT MAX(sal),
       MIN(sal)
  FROM emp
;