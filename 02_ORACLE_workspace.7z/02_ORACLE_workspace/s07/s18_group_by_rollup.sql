EXPLAIN PLAN FOR
SELECT deptno, job, AVG(NVL(sal,0)) AS avg_sal, COUNT(*) AS emp_cnt
  FROM emp
 GROUP BY ROLLUP(job,deptno)
 ORDER BY deptno,job
; 