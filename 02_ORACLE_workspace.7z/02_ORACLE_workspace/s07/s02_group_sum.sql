
SELECT ename,
       sal,
	   comm
  FROM emp
;  