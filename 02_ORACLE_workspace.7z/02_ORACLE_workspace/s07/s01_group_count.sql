SELECT COUNT(*),
       COUNT(mgr),
	   COUNT(empno),
	   COUNT(DISTINCT deptno)
  FROM emp
;  