DROP TABLE sales;

CREATE TABLE sales (
  region    VARCHAR2(20),
  product   VARCHAR2(20),
  amount    NUMBER
);

INSERT INTO sales VALUES ('Seoul', 'Laptop', 1000);
INSERT INTO sales VALUES ('Seoul', 'Phone', 500);
INSERT INTO sales VALUES ('Busan', 'Laptop', 800);
INSERT INTO sales VALUES ('Busan', 'Phone', 400);
COMMIT;