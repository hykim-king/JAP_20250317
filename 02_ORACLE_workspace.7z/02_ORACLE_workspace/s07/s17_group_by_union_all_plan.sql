EXPLAIN PLAN FOR
SELECT *
  FROM(
        SELECT deptno, job, AVG(NVL(sal,0)) AS avg_sal, COUNT(*) AS emp_cnt
          FROM emp
         GROUP BY deptno,job  
        UNION ALL 
        SELECT deptno, null,AVG(NVL(sal,0)) AS avg_sal, COUNT(*) AS emp_cnt
          FROM emp
         GROUP BY deptno 
        UNION ALL 
        SELECT null, null,AVG(NVL(sal,0)) AS avg_sal, COUNT(*) AS emp_cnt
          FROM emp
        )  
 ORDER BY deptno,job  
; 

--plan_table_output ��� FORMAT
--COL plan_table_output FOR A150; 
--SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY);