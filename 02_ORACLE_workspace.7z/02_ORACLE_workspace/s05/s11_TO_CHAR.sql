COL ename FOR A12
COL hiredate FOR A12
SELECT empno,
       ename,
	   TO_CHAR(hiredate,'YYYY/MM/DD') AS hiredate,
	   sal,
	   comm,
	   TO_CHAR( (sal*12)+comm, '$99,999') AS ANNUAL_SAL,
	   TO_CHAR(((sal*12)+comm) * 1.15, '$99,999') AS "15%_UP"
  FROM emp
 WHERE comm IS NOT NULL; 