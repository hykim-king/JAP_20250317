SELECT TO_CHAR(-500,'S999') AS signed,
       TO_CHAR(-500,'999MI') AS minus_after,
	   TO_CHAR(-500,'999PR') AS pr_format
  FROM dual;