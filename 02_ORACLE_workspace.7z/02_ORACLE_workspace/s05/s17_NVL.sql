COL name FOR A15
SELECT profno,
       name,
	   bonus,
	   TO_CHAR((pay * 12 + NVL(bonus,0)),'9,999') AS total,
	   pay
  FROM professor
 WHERE deptno = 201; 