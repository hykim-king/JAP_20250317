SELECT TO_CHAR(1234.5,'$9,999.99') AS formated,
       TO_CHAR(1234.5,'L9,999.99') AS formated2
  FROM dual
;  