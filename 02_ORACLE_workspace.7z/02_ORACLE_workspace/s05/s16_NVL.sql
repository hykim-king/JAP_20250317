DESC professor;
 �̸�           ��?      ����            
 -------------- -------- --------------
 PROFNO         NOT NULL NUMBER   (4)
 NAME           NOT NULL VARCHAR2(20)
 ID             NOT NULL VARCHAR2(15)
 POSITION       NOT NULL VARCHAR2(30)
 PAY            NOT NULL NUMBER   (3)
 HIREDATE       NOT NULL DATE
 BONUS                   NUMBER   (4)
 DEPTNO                  NUMBER   (3)
 EMAIL                   VARCHAR2(50)
 HPAGE                   VARCHAR2(50)