

COL name FOR A16
SELECT studno, 
       name,                 
	   birthday,
	   TO_CHAR(birthday,'MM') AS MON
  FROM student
 WHERE TO_CHAR(birthday,'MM') = '01' 
;

