SELECT *
  FROM emp;