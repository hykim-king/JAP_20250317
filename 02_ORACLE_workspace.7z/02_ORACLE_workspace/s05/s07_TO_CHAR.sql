SELECT TO_CHAR(45.6,'00000.00') AS formated
  FROM dual;