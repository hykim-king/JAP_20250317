--SELECT seq,title FROM board;

--DESC board;
MERGE INTO board t1
USING (
SELECT &seq        AS seq,
       '&title'    AS title,
       '&contents' AS contents,
       &read_cnt   AS read_cnt,
       '&mod_id'   AS mod_id,
       '&reg_id'   AS reg_id
  FROM dual
) t2
ON (t1.seq = t2.seq)
WHEN MATCHED  THEN 
  UPDATE SET
         t1.title    = t2.title,
         t1.contents = t2.contents,
         t1.read_cnt = t2.read_cnt,
         t1.mod_dt   = SYSDATE,
         t1.mod_id   = t2.mod_id
WHEN NOT MATCHED THEN   
  INSERT (seq,title,contents,read_cnt,reg_dt,reg_id,mod_dt,mod_id) 
  VALUES (t2.seq,t2.title,t2.contents,t2.read_cnt,SYSDATE,t2.reg_id,SYSDATE,t2.mod_id)
;  

COMMIT;