col title for a10
col mod_dt for a10
col mod_id for a10
SELECT  A.*, B.*
FROM (
        SELECT tt1.rnum AS no,
               tt1.title,
               tt1.read_cnt,
               --�������� �����̳�?yyyy/mm/dd:HH24:MI
               DECODE( TO_CHAR(SYSDATE,'YYYYMMDD'),TO_CHAR(tt1.mod_dt,'YYYYMMDD')
                      ,TO_CHAR(tt1.mod_dt,'HH24:MI')
                      ,TO_CHAR(tt1.mod_dt,'YYYY/MM/DD')) AS mod_dt,
               tt1.mod_id AS mod_id
        FROM (
                SELECT ROWNUM AS rnum, 
                       t1.title,
                       t1.read_cnt,
                       t1.mod_dt,
                       t1.mod_id
                FROM (
                        SELECT *
                          FROM board
                         ORDER BY mod_dt DESC
                )t1  
                --����
        )tt1
        --����
        WHERE RNUM BETWEEN 11 AND 20
)A
CROSS JOIN (
        SELECT COUNT(*) total_cnt
          FROM board
)B  
;