--���� ������ �Է�
--BEGIN
--    FOR i IN 1.. 1002 LOOP
--        INSERT INTO board (seq,title,contents,read_cnt,reg_dt,reg_id,mod_dt,mod_id) 
--        VALUES ( i, '����_'||i,  '����_'||i,  0,  SYSDATE-i,'ADMIN',  SYSDATE-i,'ADMIN' );    
--    END LOOP;
--    COMMIT;
--END;    
--/

--col title for a20
--SELECT tt1.rnum AS no,
--       tt1.title,
--       tt1.read_cnt,
--       --�������� �����̳�?yyyy/mm/dd:HH24:MI
--       DECODE( TO_CHAR(SYSDATE,'YYYYMMDD'),TO_CHAR(tt1.mod_dt,'YYYYMMDD')
--              ,TO_CHAR(tt1.mod_dt,'HH24:MI')
--              ,TO_CHAR(tt1.mod_dt,'YYYY/MM/DD')) AS mod_dt,
--       tt1.mod_id AS mod_id
--FROM (
--        SELECT ROWNUM AS rnum, 
--               t1.title,
--               t1.read_cnt,
--               t1.mod_dt,
--               t1.mod_id
--        FROM (
--                SELECT *
--                  FROM board
--                 ORDER BY mod_dt DESC
--        )t1  
--        --����
--        WHERE ROWNUM <=&page_size*(&page_no-1)+&page_size
--)tt1
----����(:page_no, :page_size)
--WHERE rnum >= &page_size*(&page_no-1)+1   
;

--PAGING NO : 1,2,3,...10
--SELECT COUNT(*) total_cnt
--  FROM board
--;  


--�� 2���� SQL ����: CROSS JOIN
col title for a10
col mod_dt for a10
col mod_id for a10
sql.append(" SELECT  A.*, B.*                                                                     \n");
sql.append(" FROM (                                                                               \n");
sql.append("         SELECT tt1.rnum AS no,                                                       \n");
sql.append("                tt1.title,                                                            \n");
sql.append("                tt1.read_cnt,                                                         \n");
sql.append("                DECODE( TO_CHAR(SYSDATE,'YYYYMMDD'),TO_CHAR(tt1.mod_dt,'YYYYMMDD')    \n");
sql.append("                       ,TO_CHAR(tt1.mod_dt,'HH24:MI')                                 \n");
sql.append("                       ,TO_CHAR(tt1.mod_dt,'YYYY/MM/DD')) AS mod_dt,                  \n");
sql.append("                tt1.mod_id AS mod_id                                                  \n");
sql.append("         FROM (                                                                       \n");
sql.append("                 SELECT ROWNUM AS rnum,                                               \n");
sql.append("                        t1.title,                                                     \n");
sql.append("                        t1.read_cnt,                                                  \n");
sql.append("                        t1.mod_dt,                                                    \n");
sql.append("                        t1.mod_id                                                     \n");
sql.append("                 FROM (                                                               \n");
sql.append("                         SELECT *                                                     \n");
sql.append("                           FROM board                                                 \n");
sql.append("                          ORDER BY mod_dt DESC                                        \n");
sql.append("                 )t1                                                                  \n");
sql.append("                 WHERE ROWNUM <= 10                                                   \n");
sql.append("         )tt1                                                                         \n");
sql.append("         WHERE rnum >=1                                                               \n");
sql.append(" )A                                                                                   \n");
sql.append(" CROSS JOIN (                                                                         \n");
sql.append("         SELECT COUNT(*) total_cnt                                                    \n");
sql.append("           FROM board                                                                 \n");
sql.append(" )B                                                                                   \n");
--;