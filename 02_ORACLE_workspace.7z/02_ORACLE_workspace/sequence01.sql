--SEQUENCE �̸� : PCWK_SEQ
--���۰� : 100
--�� ��  : 120
--������ : 1
--ĳ���� : 2
--��ȯ : NOCYCLE
--�ݺ� �� ���۰� : 90

--CREATE SEQUENCE PCWK_SEQ
--INCREMENT BY 1
--START WITH 100
--MAXVALUE 120
--CACHE 2
--CYCLE
--;

--CREATE TABLE PCWK_ORDER(
--  ORDER_NUMBER NUMBER(5),
--  ORDER_NAME VARCHAR2(200 CHAR),
--  PROD_NAME  VARCHAR2(200 CHAR),
--  PROD_QTY   NUMBER(5) 
--);

--INSERT INTO pcwk_order VALUES (PCWK_SEQ.NEXTVAL, '�̻�','�丶��',3);

--col ORDER_NAME for a20
--col PROD_NAME for a20
--SELECT * FROM pcwk_order ;

--SELECT PCWK_SEQ.CURRVAL FROM dual;         

INSERT INTO pcwk_order VALUES (PCWK_SEQ.NEXTVAL, '�̻�','TESLA',1);

col ORDER_NAME for a20
col PROD_NAME for a20
SELECT * FROM pcwk_order ;