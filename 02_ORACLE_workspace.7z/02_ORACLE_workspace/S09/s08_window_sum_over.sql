COL ename FOR A10
SELECT ename,
       deptno,
       sal,
       ROUND( AVG(sal) OVER(
        ORDER BY empno
        ROWS BETWEEN 1 PRECEDING AND 1 FOLLOWING
       ),2) AS avg_around
  FROM emp  
;