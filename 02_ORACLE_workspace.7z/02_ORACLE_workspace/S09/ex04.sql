COL TOTAL        FOR a12
COL SEOUL        FOR a12
COL GYEONGGI     FOR a12
COL BUSAN        FOR a12
COL ULSAN        FOR a12
COL DAEGU        FOR a12
COL GYEONGANM    FOR a12

SELECT COUNT(       SUBSTR(tel, 1,INSTR(tel,')')-1)         )||'('  || COUNT(       SUBSTR(tel, 1,INSTR(tel,')')-1)         ) /COUNT(  SUBSTR(tel, 1,INSTR(tel,')')-1)  )*100  ||'%)'  AS TOTAL, 
       COUNT(DECODE(SUBSTR(tel, 1,INSTR(tel,')')-1),'02' ,0))||'('  || COUNT(DECODE(SUBSTR(tel, 1,INSTR(tel,')')-1),'02' ,0)) /COUNT(  SUBSTR(tel, 1,INSTR(tel,')')-1)  )*100  ||'%)'  AS SEOUL,
       COUNT(DECODE(SUBSTR(tel, 1,INSTR(tel,')')-1),'031',0))||'('  || COUNT(DECODE(SUBSTR(tel, 1,INSTR(tel,')')-1),'031',0)) /COUNT(  SUBSTR(tel, 1,INSTR(tel,')')-1)  )*100  ||'%)'  AS GYEONGGI,
       COUNT(DECODE(SUBSTR(tel, 1,INSTR(tel,')')-1),'051',0))||'('  || COUNT(DECODE(SUBSTR(tel, 1,INSTR(tel,')')-1),'051',0)) /COUNT(  SUBSTR(tel, 1,INSTR(tel,')')-1)  )*100  ||'%)'  AS BUSAN,
       COUNT(DECODE(SUBSTR(tel, 1,INSTR(tel,')')-1),'052',0))||'('  || COUNT(DECODE(SUBSTR(tel, 1,INSTR(tel,')')-1),'052',0)) /COUNT(  SUBSTR(tel, 1,INSTR(tel,')')-1)  )*100  ||'%)'  AS ULSAN,
       COUNT(DECODE(SUBSTR(tel, 1,INSTR(tel,')')-1),'053',0))||'('  || COUNT(DECODE(SUBSTR(tel, 1,INSTR(tel,')')-1),'053',0)) /COUNT(  SUBSTR(tel, 1,INSTR(tel,')')-1)  )*100  ||'%)'  AS DAEGU,
       COUNT(DECODE(SUBSTR(tel, 1,INSTR(tel,')')-1),'055',0))||'('  || COUNT(DECODE(SUBSTR(tel, 1,INSTR(tel,')')-1),'055',0)) /COUNT(  SUBSTR(tel, 1,INSTR(tel,')')-1)  )*100  ||'%)'  AS GYEONGANM
  FROM student 
;