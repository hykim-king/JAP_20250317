COL ename FOR A10
SELECT ename,
       deptno,
       sal,
       SUM(sal) OVER() as sal_sum_over
  FROM emp  
;