SELECT deptno,
       COUNT(DECODE(job,'CLERK'    ,1)) AS CLERK,
       COUNT(DECODE(job,'MANAGER'  ,1)) AS MANAGER,
       COUNT(DECODE(job,'PRESIDENT',1)) AS PRESIDENT,
       COUNT(DECODE(job,'ANALYST'  ,1)) AS ANALYST,
       COUNT(DECODE(job,'SALESMAN' ,1)) AS SALESMAN
  FROM emp
 GROUP BY deptno
 ORDER BY deptno
 ;
  