

SELECT MAX(tot_sal), 
       MIN(tot_sal), 
       ROUND(AVG(tot_sal),1)
FROM (
    SELECT sal,
           comm,
           NVL(sal,0)+NVL(comm,0) tot_sal
      FROM emp
)  
;  