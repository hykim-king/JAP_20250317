COL ename FOR A10
SELECT ename,
       deptno,
       sal,
       DENSE_RANK()OVER(PARTITION BY deptno ORDER BY sal DESC) AS dense_rank_in_sal_DESC
  FROM emp
;  