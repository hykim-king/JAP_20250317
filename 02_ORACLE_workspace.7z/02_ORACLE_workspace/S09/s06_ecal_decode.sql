COL SUN FOR 99
COL MON FOR 99
COL TUE FOR 99
COL WED FOR 99
COL THU FOR 99
COL FRI FOR 99
COL SAT FOR 99

SELECT --weekno,
       --TO_NUMBER(dayno) AS dayno,
       MIN(DECODE(day,'SUN',TO_NUMBER(dayno) )) SUN,
       MIN(DECODE(day,'MON',TO_NUMBER(dayno) )) MON,
       MIN(DECODE(day,'TUE',TO_NUMBER(dayno) )) TUE,
       MIN(DECODE(day,'WED',TO_NUMBER(dayno) )) WED,
       MIN(DECODE(day,'THU',TO_NUMBER(dayno) )) THU,
       MIN(DECODE(day,'FRI',TO_NUMBER(dayno) )) FRI,
       MIN(DECODE(day,'SAT',TO_NUMBER(dayno) )) SAT
  FROM ecal
 WHERE year = '2025'
   AND month ='6'
 GROUP BY weekno   
 ORDER BY weekno 
;  
