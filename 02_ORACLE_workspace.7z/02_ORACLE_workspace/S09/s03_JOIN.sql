EXPLAIN PLAN FOR
SELECT /*+ USE_NL(d)  LEADING(e)*/ e.ename, d.dname
  FROM emp e
  JOIN dept d ON e.deptno = d.deptno
 WHERE e.job = 'CLERK';