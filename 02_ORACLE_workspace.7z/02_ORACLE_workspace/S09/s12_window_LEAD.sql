SELECT empno, ename, sal,
       --LAG(sal,1,null)OVER(ORDER BY empno) AS prev_sal,
       LEAD(sal,1,null)OVER(ORDER BY empno) AS next_sal
  FROM emp;
  