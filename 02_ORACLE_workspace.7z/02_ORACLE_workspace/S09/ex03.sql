COL TOTAL        FOR 99
COL SEOUL        FOR 99
COL GYEONGGI     FOR 99
COL BUSAN        FOR 99
COL ULSAN        FOR 99
COL DAEGU        FOR 99
COL GYEONGANM    FOR 99

SELECT COUNT(       SUBSTR(tel, 1,INSTR(tel,')')-1)         ) AS TOTAL, 
       COUNT(DECODE(SUBSTR(tel, 1,INSTR(tel,')')-1),'02' ,0)) AS SEOUL,
       COUNT(DECODE(SUBSTR(tel, 1,INSTR(tel,')')-1),'031',0)) AS GYEONGGI,
       COUNT(DECODE(SUBSTR(tel, 1,INSTR(tel,')')-1),'051',0)) AS BUSAN,
       COUNT(DECODE(SUBSTR(tel, 1,INSTR(tel,')')-1),'052',0)) AS ULSAN,
       COUNT(DECODE(SUBSTR(tel, 1,INSTR(tel,')')-1),'053',0)) AS DAEGU,
       COUNT(DECODE(SUBSTR(tel, 1,INSTR(tel,')')-1),'055',0)) AS GYEONGANM
  FROM student 
;  