COL ename FOR A10
SELECT ename,
       deptno,
       sal,
       ROW_NUMBER()OVER( ORDER BY sal DESC) AS row_number_in_sal_desc,
       ROWID
  FROM emp
;  