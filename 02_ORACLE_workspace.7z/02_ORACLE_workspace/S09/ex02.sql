COL TOTAL FOR A5
COL JAN   FOR A5
COL FEB   FOR A5
COL MAR   FOR A5
COL APR   FOR A5
COL MAY   FOR A5
COL JUN   FOR A5
COL JUL   FOR A5
COL AUG   FOR A5
COL SEP   FOR A5
COL OCT   FOR A5
COL NOV   FOR A5
COL DEC   FOR A5
SELECT COUNT( * )                        || 'EA' AS TOTAL,
       COUNT( DECODE( brith_mon,'01',1)) || 'EA' AS JAN,
       COUNT( DECODE( brith_mon,'02',1)) || 'EA' AS FEB,
       COUNT( DECODE( brith_mon,'03',1)) || 'EA' AS MAR,   
       COUNT( DECODE( brith_mon,'04',1)) || 'EA' AS APR,   
       COUNT( DECODE( brith_mon,'05',1)) || 'EA' AS MAY,   
       COUNT( DECODE( brith_mon,'06',1)) || 'EA' AS JUN,   
       COUNT( DECODE( brith_mon,'07',1)) || 'EA' AS JUL,   
       COUNT( DECODE( brith_mon,'08',1)) || 'EA' AS AUG,   
       COUNT( DECODE( brith_mon,'09',1)) || 'EA' AS SEP,   
       COUNT( DECODE( brith_mon,'10',1)) || 'EA' AS OCT,   
       COUNT( DECODE( brith_mon,'11',1)) || 'EA' AS NOV,   
       COUNT( DECODE( brith_mon,'12',1)) || 'EA' AS DEC
  FROM (
    SELECT TO_CHAR(birthday,'MM') AS  brith_mon
      FROM student
  ) 
;  