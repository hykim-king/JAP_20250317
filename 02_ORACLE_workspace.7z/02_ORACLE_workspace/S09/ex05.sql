COL CLERK,       FOR 999,999
COL MANAGER,     FOR 999,999
COL PRESIDENT,   FOR 999,999
COL ANALYST,     FOR 999,999
COL SALESMAN,    FOR 999,999
COL TOTAL        FOR 999,999


SELECT deptno,
       SUM(DECODE(job,'CLERK'    ,sal,0))AS CLERK, 
       SUM(DECODE(job,'MANAGER'  ,sal,0))AS MANAGER,
       SUM(DECODE(job,'PRESIDENT',sal,0))AS PRESIDENT,
       SUM(DECODE(job,'ANALYST'  ,sal,0))AS ANALYST,
       SUM(DECODE(job,'SALESMAN' ,sal,0))AS SALESMAN,
       SUM(sal)                          AS TOTAL
  FROM ex_emp
 GROUP BY deptno
UNION ALL
SELECT NULL, SUM(CLERK), SUM(MANAGER), SUM(PRESIDENT), SUM(ANALYST), SUM(SALESMAN), SUM(TOTAL)
FROM (
    SELECT deptno,
           SUM(DECODE(job,'CLERK'    ,sal,0))AS CLERK, 
           SUM(DECODE(job,'MANAGER'  ,sal,0))AS MANAGER,
           SUM(DECODE(job,'PRESIDENT',sal,0))AS PRESIDENT,
           SUM(DECODE(job,'ANALYST'  ,sal,0))AS ANALYST,
           SUM(DECODE(job,'SALESMAN' ,sal,0))AS SALESMAN,
           SUM(sal)                          AS TOTAL
      FROM ex_emp
     GROUP BY deptno
) A
;
