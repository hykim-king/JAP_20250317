COL TOTAL        FOR 99
COL SEOUL        FOR 99
COL GYEONGGI     FOR 99
COL BUSAN        FOR 99
COL ULSAN        FOR 99
COL DAEGU        FOR 99
COL GYEONGANM    FOR 99

SELECT  total,seoul,gyeonggi,busan,ulsan,daegu,gyeonganm
  FROM ( SELECT SUBSTR(tel, 1,INSTR(tel,')')-1) area_code,
                COUNT(tel)OVER() total
           FROM student  
  )
  PIVOT
  (
    COUNT(area_code)
    FOR area_code IN (    
    '02'  AS SEOUL,
    '031' AS GYEONGGI,
    '051' AS BUSAN,
    '052' AS ULSAN,
    '053' AS DAEGU,
    '055' AS GYEONGANM
    )
  );