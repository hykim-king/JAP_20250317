SELECT weekno,
       TO_NUMBER(dayno) AS dayno,
       day
  FROM ecal
 WHERE year = '2025'
   AND month ='5'
 ORDER BY weekno,dayno  
;  