col ename for a37
col mgr_name for a12
SELECT LPAD(ename, LEVEL*4, '*') AS ename,
       level,
       prior ename as mgr_name
  FROM emp 
 START WITH empno = 7839 --PRESIDENT 
 CONNECT BY  prior empno =  mgr 
; 

ENAME                                      LEVEL MGR_NAME
------------------------------------- ---------- ------------
KING                                           1
***JONES                                       2 KING
*******SCOTT                                   3 JONES
********FORD                                   3 JONES
***********SMITH                               4 FORD
***BLAKE                                       2 KING
*******ALLEN                                   3 BLAKE
********WARD                                   3 BLAKE
******TURNER                                   3 BLAKE
*******JAMES                                   3 BLAKE
***CLARK                                       2 KING
******MILLER                                   3 CLARK

12 ���� ���õǾ����ϴ�.

��   ��: 00:00:00.00