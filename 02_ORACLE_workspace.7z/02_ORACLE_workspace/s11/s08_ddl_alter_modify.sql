--CREATE TABLE dept2_02 
--AS
--SELECT * FROM dept2
--;

--DESC dept2_02;

--MODIFY
--AREA VARCHAR2(30) �� VARCHAR2(60) 

ALTER TABLE dept2_02
MODIFY area VARCHAR2(60) 
;

DESC dept2_02;