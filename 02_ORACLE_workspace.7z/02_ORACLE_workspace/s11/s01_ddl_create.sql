CREATE TABLE new_table(
 no NUMBER(3),
 name VARCHAR2(10),
 birthday DATE
);