--CREATE TABLE dept2_01 AS
--SELECT dcode, dname
--  FROM dept2
-- WHERE dcode IN (1000,1001,1002)
--; 
--
--SELECT * FROM dept2_01;

--loc �÷�, ������ Ÿ�� VARCHAR2(10)

--ALTER TABLE dept2_01
--ADD ( loc VARCHAR2(10));
--
--COL dname FOR  A28
--COL loc FOR  A10
--SELECT * FROM dept2_01;


--DEFAULT �÷� �߰�
ALTER TABLE dept2_01
ADD ( location VARCHAR2(10) DEFAULT 'SEOUL');

SELECT * FROM dept2_01;
