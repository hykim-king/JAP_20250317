--SELECT deptno, dname FROM dept;



CREATE TABLE dept66 AS
SELECT deptno, dname FROM dept;

SELECT * FROM dept66;