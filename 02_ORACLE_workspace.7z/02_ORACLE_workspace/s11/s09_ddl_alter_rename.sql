

ALTER TABLE dept2_02
RENAME COLUMN area TO location;

SELECT * FROM dept2_02
;