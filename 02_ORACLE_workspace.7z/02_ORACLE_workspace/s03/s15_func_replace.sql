col "replace" for a17
SELECT REPLACE('Hello, World','World','Universe') "replace",
       REPLACE('2025-05-12','-','/')  "replace2"
  FROM 	dual
;  