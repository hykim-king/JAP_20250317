col "REPLACE" for a20
SELECT REPLACE(email,substr(email,3,2),'--') "REPLACE",
       substr(email,3,2) "REPLACE2"
  FROM member
;  


