SELECT rownum, 
       ename,
	   ceil(rownum/5)
  FROM emp
;  