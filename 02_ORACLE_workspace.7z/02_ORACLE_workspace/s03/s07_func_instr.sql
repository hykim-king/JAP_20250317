COL name FORM A9
COL tel FORM A14
COL area_code FORM a9
SELECT name,
       tel,
       SUBSTR(tel,1,INSTR(tel,'-')-1 ) area_code
  FROM member
;  

NAME      TEL            AREA_CODE
--------- -------------- ---------
ȫ�浿    02-345-6789    02
�迵��    031-222-3333   031
��ö��    051-2111-9999  051
�ڹμ�    042-4987-6543  042
������    053-333-7777   053