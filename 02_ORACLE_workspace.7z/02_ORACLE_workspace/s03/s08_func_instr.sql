SELECT INSTR('2025-05-12','-')      "RESULT" ,
       INSTR('2025-05-12','-',1,2)  "RESULT2",
	   INSTR('2025-05-12','-',-1)   "RESULT3",
       INSTR('2025-05-12','-',-1,2) "RESULT4" 	   
  FROM dual
;