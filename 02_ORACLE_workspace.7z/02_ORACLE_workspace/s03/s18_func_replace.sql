col tel_rep for a15
SELECT name,
       --tel,
	   --INSTR(tel,'-',-1),
	   --SUBSTR(tel,INSTR(tel,'-',-1)+1)
	   REPLACE(tel, SUBSTR(tel,INSTR(tel,'-',-1)+1),'****') tel_rep
  FROM member
;