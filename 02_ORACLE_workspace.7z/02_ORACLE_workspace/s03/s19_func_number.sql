SELECT ABS(-100)  AS abs_val,
       CEIL(10.1) AS ceil_val,
	   FLOOR(9.9) AS floor_val,
	   MOD(17,4)  AS mod_val,
	   POWER(3,3) AS power_val,
	   ROUND(123.456,1) AS round_val,
	   TRUNC(123.456,1) AS trunc_val,
	   SIGN(-15) AS sign_val,
	   SQRT(81)  AS sqrt_val
  FROM dual
;  