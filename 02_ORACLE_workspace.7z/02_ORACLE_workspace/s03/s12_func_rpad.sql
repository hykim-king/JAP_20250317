col lpad_name         for a10
col "SUBSTR_LENGTH"   for a10

SELECT ename,
       SUBSTR('123456789',LENGTH(ename)) "SUBSTR_LENGTH",
       RPAD(ename,9,SUBSTR('123456789',LENGTH(ename))) lpad_name
  FROM emp
 WHERE deptno = 20 
; 