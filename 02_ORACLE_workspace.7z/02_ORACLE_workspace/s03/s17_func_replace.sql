
SELECT name,
       REPLACE(ssn,substr(ssn,7),'-/-/-/-') "replace"
  FROM member
;  