INSERT INTO c_test2 VALUES(10,	'AAA');
INSERT INTO c_test2 VALUES(20,	'BBB');
INSERT INTO c_test2 VALUES(30,	'CCC');

SELECT * FROM c_test2;

INSERT INTO c_test1 VALUES (1,	'AAA',	    10);
INSERT INTO c_test1 VALUES (2,	'BBB',	    20);
INSERT INTO c_test1 VALUES (3,	'CCC',	    30);

SELECT * FROM c_test1;   

COMMIT;