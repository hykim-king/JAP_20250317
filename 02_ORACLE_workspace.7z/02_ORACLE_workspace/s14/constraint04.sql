ALTER TABLE ed_emp2
ADD CONSTRAINT uq_ed_emp2_name UNIQUE(name);