--exception ���̺� ����
--C:\app\user\product\21c\dbhomeXE\rdbms\admin\utlexcpt.sql

--CREATE TABLE tt550(
--	no NUMBER  CONSTRAINT chk_tt550_no CHECK( no > 5)
--);


--ALTER TABLE tt550
--DISABLE CONSTRAINT chk_tt550_no;


--INSERT INTO tt550 VALUES (6);
--INSERT INTO tt550 VALUES (7);
--
--INSERT INTO tt550 VALUES (1);//���� ���� �߻�!
--
--COMMIT;
--SELECT * FROM tt550 ;
--
--        NO
------------
--         6
--         7
--         1

--ALTER TABLE tt550 
--ENABLE VALIDATE CONSTRAINT chk_tt550_no
--EXCEPTIONS INTO scott.EXCEPTIONS; 

--col row_id for a20
--col owner for a20
--col table_name for a20
--SELECT row_id,
--       owner,
--       table_name
--  FROM exceptions;   
  
  
--SELECT rowid , no
-- FROM tt550
--WHERE rowid IN (SELECT row_id FROM exceptions ) 
--;  


--UPDATE tt550
--   SET no = 8
--  WHERE rowid = 'AAATfrAAHAAAASdAAC' ;
--  
--  
--UPDATE tt550
--   SET no = 9
--  WHERE rowid = 'AAATfrAAHAAAASdAAD' ;  
--  
--COMMIT;  

ALTER TABLE tt550 
ENABLE VALIDATE CONSTRAINT chk_tt550_no
EXCEPTIONS INTO scott.EXCEPTIONS; 