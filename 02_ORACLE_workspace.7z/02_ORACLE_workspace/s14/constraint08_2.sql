SELECT * FROM c_test1;
        NO NAME                     DEPTNO
---------- -------------------- ----------
         1 AAA                          10
         2 BBB                          20
         3 CCC                          30
         
         
DELETE FROM c_test2 
WHERE NO = 30;


SELECT * FROM c_test1;


        NO NAME                     DEPTNO
---------- -------------------- ----------
         1 AAA                          10
         2 BBB                          20