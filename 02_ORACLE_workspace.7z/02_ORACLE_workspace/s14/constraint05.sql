ALTER TABLE ed_emp2
MODIFY loc_code CONSTRAINT nn_ed_emp2_loc_code NOT NULL;