--col dname for a20
--col area for a20
--SELECT *
--  FROM dept2
--  WHERE dcode BETWEEN 9000 AND 9999;
--  
--DELETE FROM dept2
--WHERE dcode BETWEEN 9000 AND 9999;  

--����
SELECT *
  FROM dept2
  WHERE dcode BETWEEN 9000 AND 9999;
  
--Ȯ��  
COMMIT;  