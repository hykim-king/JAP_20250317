UPDATE professor t1
   SET t1.pay = t1.pay * 1.15
WHERE position = (SELECT position
                     FROM professor
                    WHERE name = 'Sharon Stone' 
)
AND pay < 250
;