SELECT *
  FROM professor;