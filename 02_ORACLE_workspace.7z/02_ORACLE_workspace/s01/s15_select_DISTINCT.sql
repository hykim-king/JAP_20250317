SELECT DISTINCT deptno,  job
  FROM emp
;  