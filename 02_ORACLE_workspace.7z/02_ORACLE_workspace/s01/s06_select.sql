column sal format 999,999.00

SELECT ename, sal
  FROM emp
;  