-- q'[']' : 대괄호안 char가 모두 문자로 인식.
col "NAME AND JOB" for a50

SELECT ename||'(' ||job|| ') , ' || ename || q'[']' ||job||'''' AS "NAME AND JOB"
  FROM emp
;