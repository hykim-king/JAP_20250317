SELECT ename|| ' is a ' ||job AS  description

  FROM emp
;  