SELECT ename|| ', it'' a ' ||job AS  description
  FROM emp
; 