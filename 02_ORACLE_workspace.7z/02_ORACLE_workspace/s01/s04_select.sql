SELECT empno,ename,sal 
  FROM emp
;  
