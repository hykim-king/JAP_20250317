SELECT ename,TO_CHAR(hiredate,'YYYY-MM-DD') AS hire_dt
  FROM emp
;  