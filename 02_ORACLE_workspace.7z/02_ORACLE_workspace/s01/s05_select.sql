COLUMN ename FORMAT A15
COLUMN job FORMAT A12

SELECT empno,ename,job
  FROM emp
;  