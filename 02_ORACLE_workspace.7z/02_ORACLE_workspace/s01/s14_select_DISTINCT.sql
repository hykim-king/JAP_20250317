SELECT DISTINCT deptno
  FROM emp
;  