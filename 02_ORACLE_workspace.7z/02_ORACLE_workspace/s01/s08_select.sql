SELECT ename, 'goog morning!' AS "Good Morning"
  FROM emp
;  