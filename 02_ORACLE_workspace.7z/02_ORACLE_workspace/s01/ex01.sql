--DESC student;
COLUMN "ID AND WEIGHT" FORMAT a50

SELECT name||'''s ID : ' ||id || ', WEIGHT is ' || weight ||'Kg' AS "ID AND WEIGHT"
  FROM student
;