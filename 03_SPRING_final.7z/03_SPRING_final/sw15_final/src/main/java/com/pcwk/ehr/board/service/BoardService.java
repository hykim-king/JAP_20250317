package com.pcwk.ehr.board.service;

import java.util.List;

import com.pcwk.ehr.board.domain.BoardDTO;
import com.pcwk.ehr.cmn.SearchDTO;
import com.pcwk.ehr.cmn.WorkDiv;

public interface BoardService extends WorkDiv<BoardDTO> {

}
