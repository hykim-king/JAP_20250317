
let sum = 0;

for(let i=1;i<=10;i++){
  sum+=i;
  //브라우저 화면에 출력
  document.writeln(sum +"<br/>");
}

console.log(`sum=${sum}`);