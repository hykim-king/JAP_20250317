function greetDefault(name='무명씨'){
    console.log(`안녕하세요. ${name}`);
}

console.log(greetDefault());
console.log(greetDefault('이상무'));