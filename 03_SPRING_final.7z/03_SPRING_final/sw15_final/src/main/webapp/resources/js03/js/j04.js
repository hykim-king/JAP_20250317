
const fruits = ['딸기','복숭아','포도','바나나'];

for(let fruit  of fruits){
  console.log(`fruit:${fruit}`);
}