function square(number){
   return number * number;
}

const result=square(5);
console.log(`result:${result}`);