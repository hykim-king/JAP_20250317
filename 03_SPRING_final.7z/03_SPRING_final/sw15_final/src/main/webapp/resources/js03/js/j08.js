sayHello();

function sayHello(){
  console.log(`안녕하세요.`);
}


const sayHi = function(){
  console.log(`안녕!`);
}

const greet = () => {
  console.log(`Hello!`);
}

sayHi();
greet();

