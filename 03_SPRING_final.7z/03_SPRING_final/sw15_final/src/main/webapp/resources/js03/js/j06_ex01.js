for(let dan=2;dan<=9;dan++){
  document.writeln("-------"+dan+"-------<br/>");
  for(let i=1;i<=9;i++){
    document.writeln(`${dan} * ${i} =${dan*i}<br/>`)
  }
   document.writeln("<br/>");
}
