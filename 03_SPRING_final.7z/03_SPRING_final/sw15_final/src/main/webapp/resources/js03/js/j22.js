const operators = {
  add:function(a,b){
    return a+b
  },

  subtract:function(a,b){
    return a-b;
  }

}

console.log(operators.add(10,5));
console.log(operators.subtract(10,5));