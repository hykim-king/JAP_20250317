function intronduce(first,...rest){
    console.log(`${first}`);
    console.log(`${rest}`);
}
intronduce('안녕','저는','행복입니다.','오늘은 즐거운 목요일 2일 전 입니다.');