const functions = [
  function(a,b){
    return a+b
  },
  function(a,b){
    return a*b
  },

];

console.log(functions[0](10,5));
console.log(functions[1](10,5));