
const user = {userId:'james',
              age:22,
              city:'서울 홍대'
};

for(let key   in user){
  console.log(`key:${key}`,user[key]);
}