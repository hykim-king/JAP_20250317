// map 배열 변환
const numbers = [14,16,19];

const doubled=numbers.map(function(n){
  return n * 2;
});

console.log(doubled);