//비동기 콜백
setTimeout(function(){
  console.log(`3초 후 시행됨`);
},3000);