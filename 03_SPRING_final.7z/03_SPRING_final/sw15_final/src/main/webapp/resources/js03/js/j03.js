let i =5;

do{
   console.log(`i=${i}`);
   i++;
}while(i>6);