
const btnButton = document.getElementById("btn");

btnButton.addEventListener("click",function(){
  alert('버튼 클릭');
});