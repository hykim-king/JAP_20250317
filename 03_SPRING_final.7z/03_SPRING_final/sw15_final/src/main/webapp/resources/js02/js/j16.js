//묵시적 형변환
let x = 5;
let y ='2';

//102
console.log("10"+2);

//8
console.log("10"-2);
//5+2=52
console.log(`${x}+${y}=${x+y}`);

//1+1 -> 2(true는 1)
console.log(1+true);
//1+0 -> 1(false는 0)
console.log(1+false);

//1+null-> 1(null은 0)
console.log(1+null);