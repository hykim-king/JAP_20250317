//console.log('age:'+age);

let age = 22;
let message ="Hello, world!";

console.log('age:'+age);
console.log('message:'+message);

//값 수정 가능
age = 21;
console.log('age:'+age);