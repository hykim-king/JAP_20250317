//Javascript코드
let name ="Hello, world!";
console.log("name:"+name);