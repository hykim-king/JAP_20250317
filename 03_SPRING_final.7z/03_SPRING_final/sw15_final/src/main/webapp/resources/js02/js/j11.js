let x = 5;
let y = '5';

console.log(`${x} == ${y} == ${x==y}`);
console.log(`${x} === ${y} == ${x===y}`);
console.log(`${x} !== ${y} == ${x!==y}`);
