let age = 20;

let result =(age>=19)?'성인':'미성년자';
console.log(`result:${result}`);
