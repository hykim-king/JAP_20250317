let name = '이상무';
let message = "안녕,"+name+"!";

console.log(message);