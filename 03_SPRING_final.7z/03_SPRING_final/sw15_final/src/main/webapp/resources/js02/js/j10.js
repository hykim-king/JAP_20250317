let x = 5;
let y = 2;
//console.log(`${x}/${y}=${x/y}`);

//console.log(`${x}%${y}=${x%y}`);

//console.log(`${x}**${y}=${x**y}`);