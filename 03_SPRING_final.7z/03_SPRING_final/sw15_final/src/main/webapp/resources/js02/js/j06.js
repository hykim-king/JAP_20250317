console.log('오늘은 즐거운 목요일 3일 입니다.');

//여러 값 출력
let name = '이상무';
let age  = 22;

console.log('name:',name,'age:',age);

//템플릿 리터럴
let language ='JavaScript';
//I am learning JavaScript.
console.log(`I am learning ${language }.`);

//객체와 배열 출력
let obj = {name:"이상무",age:22};
console.log(obj);

let arr = [22,14,16];
console.log(arr);