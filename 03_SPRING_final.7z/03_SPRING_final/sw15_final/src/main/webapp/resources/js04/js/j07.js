console.log('window.navigator.userAgent:',window.navigator.userAgent);
console.log(window.navigator.language);

//해당 페이지를 실행후,work06.html,work05.html
window.history.back();