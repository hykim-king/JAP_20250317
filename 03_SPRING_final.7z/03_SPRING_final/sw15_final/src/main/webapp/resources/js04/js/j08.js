

//현재 URL
console.log(window.location.href);

const btnButton = document.querySelector("#btn");
console.log(btnButton);

//이동
btnButton.addEventListener("click",function(e){
  //이동할 URL
  window.location.href ="work06.html";
    
});