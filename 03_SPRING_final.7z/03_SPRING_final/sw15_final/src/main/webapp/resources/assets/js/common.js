   //입력 값이 비어 있는지 확인

   //let isEmpty :변수 선언
   let isEmpty = function(value){
         if(null === value || "" === value){
            return true;
         }

         return false;
   };