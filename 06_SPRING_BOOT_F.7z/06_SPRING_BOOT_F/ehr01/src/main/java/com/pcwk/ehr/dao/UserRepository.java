package com.pcwk.ehr.dao;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pcwk.ehr.domain.SiteUser;

public interface  UserRepository  extends JpaRepository<SiteUser, Long> {
    Optional<SiteUser> findByusername(String username);

}
