package com.pcwk.ehr.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class MainController {
	
	
	public MainController() {
		log.info("┌────────────────────────────────────────────────┐");
		log.info("│ MainController()                               │");
		log.info("└────────────────────────────────────────────────┘");
	}
	
	@GetMapping("/")
	public String root() {
		return "redirect:/question/list";
	}

}
