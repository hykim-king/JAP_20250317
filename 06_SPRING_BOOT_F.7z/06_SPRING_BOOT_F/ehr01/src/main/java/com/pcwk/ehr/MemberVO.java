package com.pcwk.ehr;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MemberVO {
	private String memberId;// 회원ID
	private String name;// 이름
	private String password;// 비밀번호
	private String email;// 이메일
	private int loginCount;// 로그인 횟수
	private String regDt;// 가입일
	private String role;// 권한
	
	
	public static void main(String[] args) {
		MemberVO user=new MemberVO();
		// setter
		user.setMemberId("pcwk01");
		user.setName("홍길동");

		// getter
		System.out.println(user.getName());
		System.out.println(user.getMemberId());

		// toString
		System.out.println(user.toString());
	}
}
