package com.pcwk.ehr.domain;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/*
id	답변 데이터의 고유 번호
subject	질문 데이터 (어떤 질문의 답변인지 알아야 하므로 이 속성이 필요하다.)
content	답변 데이터의 내용
createDate	답변 데이터를 작성한 일시
@NoArgsConstructor : default생성자
@AllArgsConstructor: 모든 argments 생성자
*/
@Getter
@Setter
@Entity
//@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Question {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(length = 200)
	private String subject;

	@Column(columnDefinition = "TEXT")
	private String content;

	private LocalDateTime createDate;

	// 1:N
	// cascade = CascadeType.REMOVE : Oracle ON DELETE CASCASE
	// Question 데이터 삭제시 관련 자식 Answer 데이터도 같이 삭제.
	@OneToMany(mappedBy = "question", cascade = CascadeType.REMOVE)
	private List<Answer> answer;

    @ManyToOne
    private SiteUser author;     
    
    private LocalDateTime modifyDate;
}
