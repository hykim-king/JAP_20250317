package com.pcwk.ehr.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.PageRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pcwk.ehr.cmn.DataNotFoundException;
import com.pcwk.ehr.controller.QuestionController;
import com.pcwk.ehr.dao.QuestionRepository;
import com.pcwk.ehr.domain.Question;
import com.pcwk.ehr.domain.SiteUser;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class QuestionService {
	
	@Autowired
	QuestionRepository questionRepository;

	public QuestionService() {
		log.info("┌────────────────────────────────────────────────┐");
		log.info("│ QuestionService()                              │");
		log.info("└────────────────────────────────────────────────┘");
		
	}
    public void delete(Question question) {
        this.questionRepository.delete(question);
    }
    
    
    public void modify(Question question, String subject, String content) {
        question.setSubject(subject);
        question.setContent(content);
        question.setModifyDate(LocalDateTime.now());
        this.questionRepository.save(question);
    }
    
	/**
	 * 질문 페이징 
	 * @param page
	 * @return Page<Question>
	 */
	public Page<Question>  getList(int page){
		Pageable pageable=PageRequest.of(page, 10,Sort.by("createDate").descending());
		log.info("1.param page:"+page);	
		
		return questionRepository.findAll(pageable);
		
	}
	
	
	/**
	 * 질문등록
	 * @param subject
	 * @param content
	 * @return Question(PK = id가 포함됨)
	 */
	public Question create(String subject, String content, SiteUser user) {
		log.info("1.param subject:"+subject);
		log.info("1.param content:"+content);
		
		Question question=new Question();
		question.setSubject(subject);
		question.setContent(content);
		question.setCreateDate(LocalDateTime.now());
		question.setAuthor(user);
		
		Question outVO = questionRepository.save(question);
		log.info("2.Question outVO :"+outVO);
		return outVO;		
	}
	
	
	/**
	 * 질문 상셍 
	 * @param id
	 * @return Question
	 */
	public Question detail(Integer id) {
		log.info("┌──────────────────────┐");
		log.info("│ detail()             │");
		log.info("└──────────────────────┘");
		
		log.info("id: "+id);
		Optional<Question>  optOutVO = questionRepository.findById(id);
		
		if(optOutVO.isPresent()) {
			return optOutVO.get();
		}else {
			throw new DataNotFoundException("question not found");
		}
		
	}
	
	/**
	 * 전체목록 조회
	 * @return List<Question> 
	 */
	public List<Question> list(){
		log.info("┌──────────────────────┐");
		log.info("│ list()               │");
		log.info("└──────────────────────┘");		
		return questionRepository.findAll();
	}
	
	
}
