package com.pcwk.ehr;

import java.beans.BeanProperty;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.header.writers.frameoptions.XFrameOptionsHeaderWriter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import com.pcwk.ehr.controller.AnswerController;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration // 설정 클래스임을 의비 합니다.
@EnableWebSecurity // Spring Security 설정을 활성화 합니다.
@EnableMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

	// http.authorizeHttpRequests : http요청에 대한 접근 권한 규칙을 정의 합니다.
	// requestMatchers(new AntPathRequestMatcher("/**")).permitAll() ) : 모든 URL(/**)
	// 요청에 대해 인가 검사 없이 허용(permitAll)
	@Bean
	SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		log.info("┌────────────────────────────────────────────────┐");
		log.info("│ filterChain()                                  │" + http);
		log.info("└────────────────────────────────────────────────┘");
		http.authorizeHttpRequests((authorizeHttpRequests) -> authorizeHttpRequests
				.requestMatchers(new AntPathRequestMatcher("/**")).permitAll())
				/// h2-console 접근 허용
				.csrf((csrf) -> csrf.ignoringRequestMatchers(new AntPathRequestMatcher("/h2-console/**")))
				.headers((headers) -> headers.addHeaderWriter(
						new XFrameOptionsHeaderWriter(XFrameOptionsHeaderWriter.XFrameOptionsMode.SAMEORIGIN)))
				.formLogin((formLogin) -> formLogin.loginPage("/user/login").defaultSuccessUrl("/"))
	            .logout((logout) -> logout
	                    .logoutRequestMatcher(new AntPathRequestMatcher("/user/logout"))
	                    .logoutSuccessUrl("/")
	                    .invalidateHttpSession(true))
				;
		

		return http.build();
	}

	@Bean
	PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration)
			throws Exception {
		return authenticationConfiguration.getAuthenticationManager();
	}
}
