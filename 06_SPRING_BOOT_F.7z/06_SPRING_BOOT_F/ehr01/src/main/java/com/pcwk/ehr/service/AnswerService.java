package com.pcwk.ehr.service;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pcwk.ehr.cmn.DataNotFoundException;
import com.pcwk.ehr.dao.AnswerRepository;
import com.pcwk.ehr.domain.Answer;
import com.pcwk.ehr.domain.Question;
import com.pcwk.ehr.domain.SiteUser;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class AnswerService {

	@Autowired
	AnswerRepository answerRepository;

	public AnswerService() {
		log.info("┌────────────────────────────────────────────────┐");
		log.info("│ AnswerService()                                │");
		log.info("└────────────────────────────────────────────────┘");
		
	}
	
    public void delete(Answer answer) {
        this.answerRepository.delete(answer);
    }
    
    
    public Answer getAnswer(Integer id) {
        Optional<Answer> answer = this.answerRepository.findById(id);
        if (answer.isPresent()) {
            return answer.get();
        } else {
            throw new DataNotFoundException("answer not found");
        }
    }

    public void modify(Answer answer, String content) {
        answer.setContent(content);
        answer.setModifyDate(LocalDateTime.now());
        this.answerRepository.save(answer);
    }
    
	
	/**
	 * 답변등록
	 * @param question
	 * @param content
	 * @return Answer(등록 ID가 있는)
	 */
	public Answer create(Question question, String content, SiteUser author) {
		
		//log.info("question: "+question);
		log.info("content: "+content);
        Answer answer = new Answer();
        answer.setContent(content);
        answer.setCreateDate(LocalDateTime.now());
        answer.setQuestion(question);
        answer.setAuthor(author);
        this.answerRepository.save(answer);
		
		Answer outVO = answerRepository.save(answer);

		//log.info("outVO: "+outVO);
		return outVO;
	}
	
}
