package com.pcwk.ehr.domain;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Entity
//@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Answer {

	//pk
	//@GeneratedValue : key
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(columnDefinition ="TEXT" )
	private String content;
	
	private LocalDateTime createDate;
	
	@ManyToOne
	private Question question;
	
    @ManyToOne
    private SiteUser author;	
    
    private LocalDateTime modifyDate;
	
}
