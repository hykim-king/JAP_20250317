package com.pcwk.ehr.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.pcwk.ehr.domain.Question;



public interface QuestionRepository extends JpaRepository<Question, Integer> {
	
	/**
	 * 제목으로 조회
	 * @param subject
	 * @return Question
	 */
	Question findBySubject(String subject);
	
	/**
	 * findBySubjectAndcontent : 카멜케이스 Naming rule 지키지 않으면 오류( ex)findBySubjectandcontent
	 * 제목 AND content
	 * @param subject
	 * @param content
	 * @return Question
	 */
	Question findBySubjectAndContent(String subject, String content);
	
	/**
	 * findBySubjectLike : %subject%
	 * @param subject
	 * @return List<Question>
	 */
	List<Question> findBySubjectLike(String subject);

    /**
     * 페이징
     */
	Page<Question> findAll(Pageable pageable); 
	
}
