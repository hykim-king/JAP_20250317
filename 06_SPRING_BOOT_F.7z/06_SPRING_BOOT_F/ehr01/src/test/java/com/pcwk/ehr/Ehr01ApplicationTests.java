package com.pcwk.ehr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ehr01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
