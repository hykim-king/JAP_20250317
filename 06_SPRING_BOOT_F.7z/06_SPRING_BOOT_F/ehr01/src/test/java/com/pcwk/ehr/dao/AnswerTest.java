package com.pcwk.ehr.dao;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Commit;

import com.pcwk.ehr.domain.Answer;
import com.pcwk.ehr.domain.Question;
import com.pcwk.ehr.domain.SiteUser;

import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@SpringBootTest
class AnswerTest {
	//수동으로 생성
	Logger  slLog=LoggerFactory.getLogger(QuestionTest.class);
	
	@Autowired
	QuestionRepository questionRepository;
	
	@Autowired
	AnswerRepository answerRepository;
	
	
	Question question01;
	
	Answer answer01;
	Answer answer02;
	
	SiteUser siteUser01;
	
	@BeforeEach
	void setUp() throws Exception {
		log.info("┌─────────────────────────────────────────────────────────┐");
		log.info("│ setUp()                                                 │");
		log.info("└─────────────────────────────────────────────────────────┘");	
		LocalDateTime createDate = LocalDateTime.now();
		List<Answer>  answerList=new ArrayList<>();
		siteUser01=new SiteUser();
		siteUser01.setUsername("james01");
		question01=new Question(null, "제목01","내용1", createDate, answerList,siteUser01,createDate);
		
		
		
		//1. Question 전체 삭제
		//2. Question 단건 등록
		
		//1. Question 전체 삭제
		questionRepository.deleteAll();
		assertEquals(0, questionRepository.count());
		log.info("1.questionRepository.count():{}", questionRepository.count());
		
		//2.
		question01 = questionRepository.save(question01);
		assertEquals(1, questionRepository.count());
		assertNotNull(question01);
		
		log.info("2.getId:{}",question01.getId());
		log.info("2.getSubject:{}",question01.getSubject());
		log.info("2.getContent:{}",question01.getContent());	
		//-Question--------------------------------------------------------------
		answer01 = new Answer(null, "답변1", createDate, question01,siteUser01,createDate);
		answer02 = new Answer(null, "답변2", createDate, question01,siteUser01,createDate);
		log.info("3.answer01:{}",answer01);
		

	}

	@AfterEach
	void tearDown() throws Exception {
		log.info("┌─────────────────────────────────────────────────────────┐");
		log.info("│ tearDown()                                              │");
		log.info("└─────────────────────────────────────────────────────────┘");			
	}

//	@Transactional
//	@Commit
//	@Test
//	void questionFindAnswer() {
//
//		answer01=answerRepository.save(answer01);
//		answer02=answerRepository.save(answer02);
//		
//		Optional<Question> oq= questionRepository.findById(question01.getId());		
//		Question q=oq.get();	
//		log.info("1. q.getId():{}",q);
//		
//		List<Answer> answerList=q.getAnswer();
//		
//		for(Answer vo :answerList) {
//			log.info("vo:{}",vo);
//		}
//	}
	
	@Disabled
	@Test
	void addAndGet() {
		log.info("┌──────────────────────┐");
		log.info("│ addAndGet()          │");
		log.info("└──────────────────────┘");		
		
		//단독으로 수행시 : 매번 동일한 결과를 낮도록 수행
		// Answer
		//1. 전체 삭제
		//2. 단건 등록
		//3. 단건 조회
		
		//1.
		answerRepository.deleteAll();
		assertEquals(0, answerRepository.count());
		log.info("1. answerRepository.count():{}",answerRepository.count());
		
		//2.
		answer01=answerRepository.save(answer01);
		assertEquals(1, answerRepository.count());
		log.info("2. answer01.getId():{}",answer01.getId());
		
		//3. 
		Optional<Answer> optOutVO = answerRepository.findById(answer01.getId());
		assertTrue(optOutVO.isPresent()); //데이터가 존재 하는지
		
		if (optOutVO.isPresent() == true) {
			Answer outVO = optOutVO.get();
			log.info("Answer outVO.getId():{}",outVO.getId());
			log.info("Answer outVO.getContent():{}",outVO.getContent());
		}
	}
	
	@Disabled
	@Test
	void beans() {
		log.info("┌──────────────────────┐");
		log.info("│ beans()              │");
		log.info("└──────────────────────┘");		
		
		assertNotNull(questionRepository);
		assertNotNull(answerRepository);
		
		log.info("questionRepository:{}",questionRepository);
		log.info("answerRepository:{}",answerRepository);
		
	}

}
