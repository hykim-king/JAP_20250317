package com.pcwk.ehr.dao;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.test.annotation.Commit;

import com.pcwk.ehr.domain.Answer;
import com.pcwk.ehr.domain.Question;
import com.pcwk.ehr.domain.SiteUser;

import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
class QuestionTest {
   
	//수동으로 생성
	Logger  slLog=LoggerFactory.getLogger(QuestionTest.class);
	
	@Autowired
	QuestionRepository questionRepository;
	
	
	Question question01;
	Question question02;
	Question question03;
	
	SiteUser siteUser01;
	
	
	@BeforeEach
	void setUp() throws Exception {
		log.info("┌─────────────────────────────────────────────────────────┐");
		log.info("│ setUp()                                                 │");
		log.info("└─────────────────────────────────────────────────────────┘");
		
		siteUser01=new SiteUser();
		siteUser01.setUsername("james01");
		
		//전일
		LocalDateTime createDate = LocalDateTime.now();
		List<Answer>  answerList=new ArrayList<>();
		
		question01=new Question(null, "제목01","내용1", createDate, answerList,siteUser01,createDate);
		question02=new Question(null, "제목02","내용2", createDate.minusDays(-1), answerList,siteUser01,createDate);
		question03=new Question(null, "제목03","내용3", createDate.minusDays(-2), answerList,siteUser01,createDate);
		
		
	}

	@AfterEach
	void tearDown() throws Exception {
		log.info("┌─────────────────────────────────────────────────────────┐");
		log.info("│ tearDown()                                              │");
		log.info("└─────────────────────────────────────────────────────────┘");		
	}
	
	@Test
	void findBySubjectLike() {
		log.info("┌──────────────────────┐");
		log.info("│ findBySubjectLike()  │");
		log.info("└──────────────────────┘");			
		//단독으로 수행시 : 매번 동일한 결과를 낮도록 수행
		//1. 전체 삭제
		//2. 다건 등록
		//3. 제목 LIKE검색
		
		//1.
		questionRepository.deleteAll();
		assertEquals(0, questionRepository.count());
		log.info("1.questionRepository.count():{}", questionRepository.count());
		
		//2.
		List<Question>  postList=new ArrayList<>();
		final int TOTAL_SAVE_CNT = 502; //저장 데이터 건수
		LocalDateTime createDate = LocalDateTime.now();//등록일
		
		for( int i=1;i<=TOTAL_SAVE_CNT;i++) {
			postList.add(new Question(null, "제목"+i, "내용"+i, createDate.minusDays(i), new ArrayList<Answer>() ,siteUser01,createDate));	
		}
		
		//다건 등록
		questionRepository.saveAll(postList);
		assertEquals(TOTAL_SAVE_CNT, questionRepository.count());
		
		
		//3. 제목 LIKE검색
		List<Question> questionList = questionRepository.findBySubjectLike("%제목10%");
		for(Question vo :questionList) {
			log.info("vo:subject {}",vo.getSubject());
		}
		
	}
	
	
	@Disabled
	@Test
	void selectSubjectAndContent() {
		log.info("┌──────────────────────┐");
		log.info("│ selectSubjectAndContent()│");
		log.info("└──────────────────────┘");	
		
		//단독으로 수행시 : 매번 동일한 결과를 낮도록 수행
		//1. 전체 삭제
		//2. 단건 등록
		//3. 제목 and 내용으로 조회
		
		//1.
		questionRepository.deleteAll();
		assertEquals(0, questionRepository.count());
		log.info("1.questionRepository.count():{}", questionRepository.count());

		
		//2.
		question01 = questionRepository.save(question01);
		assertEquals(1, questionRepository.count());
		assertNotNull(question01);	
		
		
		//3. 
		Question outVO=questionRepository.findBySubjectAndContent(
						question01.getSubject(), question01.getContent());
		
		assertNotNull(outVO);
		
		log.info("subject:{}",outVO.getSubject());
		log.info("content:{}",outVO.getContent());				
		
	}
	
	
	@Disabled
	@Test
	void selectSubject() {
		log.info("┌──────────────────────┐");
		log.info("│ selectSubject()      │");
		log.info("└──────────────────────┘");
		//단독으로 수행시 : 매번 동일한 결과를 낮도록 수행
		//1. 전체 삭제
		//2. 단건 등록
		//3. 제목으로 조회
		
		//1.
		questionRepository.deleteAll();
		assertEquals(0, questionRepository.count());
		log.info("1.questionRepository.count():{}", questionRepository.count());
					
		//2.
		question01 = questionRepository.save(question01);
		assertEquals(1, questionRepository.count());
		assertNotNull(question01);	
		
		//3. 
		//sql
		//select * from question q1_0 where q1_0.subject=?
		Question outVO=questionRepository.findBySubject(question01.getSubject());
		assertNotNull(outVO);
		
	}
	
	
	
	@Disabled
	@Commit
	@Transactional
	@Test
	void doUpdate() {
		log.info("┌──────────────────────┐");
		log.info("│ doUpdate()           │");
		log.info("└──────────────────────┘");
		
		//단독으로 수행시 : 매번 동일한 결과를 낮도록 수행
		//1. 전체 삭제
		//2. 단건 등록
		//3. 한건 조회
		//4. 수정
		
		//1.
		questionRepository.deleteAll();
		assertEquals(0, questionRepository.count());
		log.info("1.questionRepository.count():{}", questionRepository.count());
				
		//2.
		question01 = questionRepository.save(question01);
		assertEquals(1, questionRepository.count());
		assertNotNull(question01);	
		
		//3.
		Optional<Question>  optOutVO =questionRepository.findById(question01.getId());
		log.info("2.optOutVO.isPresent():{}", optOutVO.isPresent());
		assertTrue(optOutVO.isPresent()); //데이터가 존재 하는지
		
		Question outVO = optOutVO.get();
		log.info("3.getSubject:{}",outVO.getSubject());
		log.info("3.getContent:{}",outVO.getContent());
		
		
		assertEquals(question01.getSubject(), outVO.getSubject());
		assertEquals(question01.getContent(), outVO.getContent());
		
		//4. 데이터 수정
		String updateString = "_U";
		
		outVO.setSubject(outVO.getSubject()+updateString);
		outVO.setContent(outVO.getContent()+updateString);
		
		
		Question upOutVO=questionRepository.save(outVO);
		log.info("4.upOutVO:\n"+upOutVO);
		
		
		//5.
		Optional<Question>  optOutVOSel =questionRepository.findById(upOutVO.getId());
		log.info("5.optOutVOSel.isPresent():{}", optOutVOSel.isPresent());
		assertTrue(optOutVOSel.isPresent()); //데이터가 존재 하는지
		
		Question outVOSel = optOutVOSel.get();
		log.info("5.getSubject:{}",outVOSel.getSubject());
		log.info("5.getContent:{}",outVOSel.getContent());
		
	}
	
	
	//@Disabled
	@Test
	void doRetrieve() {
		log.info("┌──────────────────────┐");
		log.info("│ doRetrieve()         │");
		log.info("└──────────────────────┘");			
		
		//1. 전체 삭제
		//2. 다건등록:502
		
		//1.
		questionRepository.deleteAll();
		assertEquals(0, questionRepository.count());		
		
		
		//2.
		List<Question>  postList=new ArrayList<>();
		final int TOTAL_SAVE_CNT = 502; //저장 데이터 건수
		LocalDateTime createDate = LocalDateTime.now();//등록일
		
		for( int i=1;i<=TOTAL_SAVE_CNT;i++) {
			postList.add(new Question(null, "제목"+i, "내용"+i, createDate.minusDays(i), new ArrayList<Answer>() ,siteUser01,createDate));	
		}
		
		//다건 등록
		questionRepository.saveAll(postList);
		assertEquals(TOTAL_SAVE_CNT, questionRepository.count());
		
		//paging:
		PageRequest pageRequest=PageRequest.of(0, 10, Sort.by("createDate").descending());
		
		Page<Question> reuslt = questionRepository.findAll(pageRequest);
		
		
		log.info("총 페이지수 :"+reuslt.getTotalPages());
		log.info("총 데이터 :"+reuslt.getTotalElements());
		log.info("현재 페이지 데이터 수 :"+reuslt.getNumberOfElements());
		
		
		for(Question vo:  reuslt.getContent()) {
			log.info("제목->"+vo.getSubject());
		}
		
		assertEquals(10, reuslt.getNumberOfElements());
		assertEquals(TOTAL_SAVE_CNT, reuslt.getTotalElements());
		
	}
	
	
	
	@Disabled
	@Test
	void doDelete() {
		log.info("┌──────────────────────┐");
		log.info("│ doDelete()           │");
		log.info("└──────────────────────┘");	
		//단독으로 수행시 : 매번 동일한 결과를 낮도록 수행
		//1. 전체 삭제
		//2. 단건 등록
		//2.1 등록 건수 비교
		//3. 삭제
		//3.1 건수 비교
		
		//1.
		questionRepository.deleteAll();
		assertEquals(0, questionRepository.count());
		
		//2.
		question01 = questionRepository.save(question01);
		assertEquals(1, questionRepository.count());
		assertNotNull(question01);	
		
		//3.
		questionRepository.deleteById(question01.getId());
		assertEquals(0, questionRepository.count());
		
		
	}
	
	
	@Test
	void testQuestionToAnswer() {
		
	}
	
	
	@Disabled
	@Test
	void addAndGet() {
		//단독으로 수행시 : 매번 동일한 결과를 낮도록 수행
		//1. 전체 삭제
		//2. 단건 등록
		//3. 한건 조회
		
		
		log.info("┌──────────────────────┐");
		log.info("│ addAndGet()          │");
		log.info("└──────────────────────┘");		
		
		//1.
		questionRepository.deleteAll();
		assertEquals(0, questionRepository.count());
		log.info("1.questionRepository.count():{}", questionRepository.count());
		
		//2.
		question01 = questionRepository.save(question01);
		assertEquals(1, questionRepository.count());
		assertNotNull(question01);
		
		//3.
		Optional<Question>  optOutVO =questionRepository.findById(question01.getId());
		log.info("2.optOutVO.isPresent():{}", optOutVO.isPresent());
		assertTrue(optOutVO.isPresent()); //데이터가 존재 하는지
		
		Question outVO = optOutVO.get();
		log.info("3.getSubject:{}",outVO.getSubject());
		log.info("3.getContent:{}",outVO.getContent());
		
		
		
		assertEquals(question01.getSubject(), outVO.getSubject());
		assertEquals(question01.getContent(), outVO.getContent());

	}
	
	
	@Disabled
	@Test
	void beans() {
		log.info("┌──────────────────────┐");
		log.info("│ beans()              │");
		log.info("└──────────────────────┘");			
		slLog.info("Logger  slLog=LoggerFactory.getLogger(QuestionTest.class)");
		assertNotNull(questionRepository);
		log.info("questionRepository:"+questionRepository);
		
	}

}
