package com.pcwk.ehr;
import java.time.Duration;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.reactive.function.client.WebClient;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@Controller
public class IrisController {

	

	@Autowired
	WebClient fastapiWebClient; 

	
    @GetMapping("/iris")
    public String iris(Model model) {
        log.info("=iris()=");

        return "classfication_iris"; // templates/classfication_iris.html
    }
	
}
