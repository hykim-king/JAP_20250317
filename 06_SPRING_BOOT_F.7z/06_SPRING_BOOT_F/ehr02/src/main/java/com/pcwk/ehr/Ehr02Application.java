package com.pcwk.ehr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ehr02Application {

	public static void main(String[] args) {
		SpringApplication.run(Ehr02Application.class, args);
	}

}
