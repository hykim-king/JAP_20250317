package com.pcwk.ehr;
import java.time.Duration;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.reactive.function.client.WebClient;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@Controller
public class HelloController {

	

	@Autowired
	WebClient fastapiWebClient; 

	
    @GetMapping("/hello")
    public String hello(Model model) {
        log.info("=hello()=");

        // 1) 로컬 값
        model.addAttribute("name","Spring Boot & Thymeleaf");

        // 2) FastAPI GET 호출: /hello/{name} → {"greeting":"Hello, Alice!"}
        Map<String, Object> remote = null;
        try {
            remote = fastapiWebClient.get()
                    .uri(uri -> uri.path("/hello/{name}").build("Alice"))
                    .retrieve()
                    .bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {})
                    .block(Duration.ofSeconds(3));
        } catch (Exception e) {
            log.warn("FastAPI GET 호출 실패: {}", e.toString());
        }
        
        log.info("greeting:"+remote.getOrDefault("greeting","(no response)").toString());
        
        
        model.addAttribute("remoteGreeting",
                remote != null ? remote.getOrDefault("greeting","(no response)") : "(error)");

        return "hello"; // templates/hello.html
    }
	
}
