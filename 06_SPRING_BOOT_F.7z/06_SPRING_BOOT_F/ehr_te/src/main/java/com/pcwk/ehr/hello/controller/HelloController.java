package com.pcwk.ehr.hello.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HelloController {

	
	@GetMapping("/hello.do")
	@ResponseBody
	public String hello() {
		return "점심 맛나게 하셨나요?!^^^@@";
	}
	
}
