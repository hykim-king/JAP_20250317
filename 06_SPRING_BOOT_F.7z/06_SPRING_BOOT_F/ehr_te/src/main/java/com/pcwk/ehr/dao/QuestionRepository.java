package com.pcwk.ehr.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pcwk.ehr.question.domain.Question;

public interface QuestionRepository extends JpaRepository<Question, Integer> {

}
