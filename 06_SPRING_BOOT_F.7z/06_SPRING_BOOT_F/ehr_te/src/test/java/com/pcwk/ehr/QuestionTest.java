package com.pcwk.ehr;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.test.annotation.Commit;

import com.pcwk.ehr.answer.domain.Answer;
import com.pcwk.ehr.dao.QuestionRepository;
import com.pcwk.ehr.question.domain.Question;

import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
class QuestionTest {
   
	
    @Autowired
    private QuestionRepository questionRepository;
    
    Question question01;
    
	@BeforeEach
	void setUp() throws Exception {
		log.info("┌─────────────────────────────────────────────────────────┐");
		log.info("│ setUp()                                                 │");
		log.info("└─────────────────────────────────────────────────────────┘");	
		LocalDateTime now = LocalDateTime.now().minusDays(1);//하루 빼기
		List<Answer> answerList =new ArrayList<>();
		question01 = new Question(0, "제목01", "내용01",now , answerList);
		
	}

	@AfterEach
	void tearDown() throws Exception {
		log.info("┌─────────────────────────────────────────────────────────┐");
		log.info("│ tearDown()                                              │");
		log.info("└─────────────────────────────────────────────────────────┘");		
	}
	
	@Disabled
	@Test
	void doRetrieve() {
		log.info("┌───────────────────────────┐");
		log.info("│ *doRetrieve()*            │");
		log.info("└───────────────────────────┘");			
		// 매번 동일한 결과가 도출 되도록 작성
		//1. 전체삭제
		//2. 다건등록
		//3. paging조회
		
		//1.
		questionRepository.deleteAll();
		assertEquals(0, questionRepository.count());
		
		//2. 다건등록
        List<Question> postList = new ArrayList<>();
        for (int i = 1; i <= 502; i++) {
        	LocalDateTime now = LocalDateTime.now();
            postList.add(new Question(0, "제목"+i, "내용"+i,now , new ArrayList<Answer>()));
        }
        questionRepository.saveAll(postList);	
        assertEquals(502, questionRepository.count());
        
        //3. paging조회
        PageRequest pageRequest =PageRequest.of(0, 10,Sort.by("createDate").descending());
        Page<Question> result = questionRepository.findAll(pageRequest);
        
        log.info("총 페이지 수:"+result.getTotalPages());
        log.info("총 데이터 수:"+result.getTotalElements());
        log.info("현재 페이지 데이터 수:"+result.getNumberOfElements());
        
        
       for (Question q :result.getContent()) {
    	   log.info("제목: "+q.getSubject());
       }
       assertEquals(10, result.getNumberOfElements());
       assertEquals(502, result.getTotalElements());       
       
        
        
        log.info(null);
	}
	
	
	
	//@Disabled
	@Transactional
	@Commit
	@Test
	void doUpdate() {
		log.info("┌───────────────────────────┐");
		log.info("│ *doUpdate()*              │");
		log.info("└───────────────────────────┘");		
		// 매번 동일한 결과가 도출 되도록 작성
		//1. 전체삭제
		//2. 단건등록
		//3. 단건조회
		//4. 조회데이터 수정

		
		// 1.
		questionRepository.deleteAll();
		assertEquals(0, questionRepository.count());
		// 2.
		question01 = questionRepository.save(question01);
		assertNotNull(question01);
		log.info("question01:{}", question01);

		Optional<Question> optOutVO = questionRepository.findById(question01.getId());
		assertTrue(optOutVO.isPresent());
		
		Question outVO = optOutVO.get();
		
		//4. 
		String upString = "_U";
		int    upInt    = 999;
		
		outVO.setSubject(outVO.getSubject()+upString);
		outVO.setContent(outVO.getContent()+upString);
		
		questionRepository.flush();// flush()로 UPDATE 즉시 실행
		
		// @Transactional 때문에 테스트 끝날 때 롤백됨
		//Question upOutVO = questionRepository.save(outVO);
//		log.info("upOutVO: "+upOutVO);
		
		
	}
	
	@Disabled
	@Test
	void doDelete() {
		log.info("┌───────────────────────────┐");
		log.info("│ *doDelete()*              │");
		log.info("└───────────────────────────┘");			
		// 매번 동일한 결과가 도출 되도록 작성
		//1. 전체삭제
		//2. 단건등록
		//2.1 등록건수 비교
		//3. 삭제
		//4. 등록건수 비교==0
		
		//1.
		questionRepository.deleteAll();
		assertEquals(0, questionRepository.count());
		// 2.
		question01 = questionRepository.save(question01);	
		assertEquals(1, questionRepository.count());
		//3.
		questionRepository.deleteById(question01.getId());
		assertEquals(0, questionRepository.count());
	}
	
	@Disabled
	@Test
	void addAndGet() {
		// 매번 동일한 결과가 도출 되도록 작성
		// 1.전체삭제
		// 2.단건등록
		// 3.단건조회
		
		// 1.
		questionRepository.deleteAll();
		assertEquals(0, questionRepository.count());
		// 2.
		question01 = questionRepository.save(question01);
		assertNotNull(question01);
		log.info("question01:{}", question01);

		Optional<Question> optOutVO = questionRepository.findById(question01.getId());
		assertTrue(optOutVO.isPresent());
		
		Question outVO = optOutVO.get();

		
		assertEquals("제목01", outVO.getSubject());
		assertEquals("내용01", outVO.getContent());
	}
	
	@Disabled
	@Test
	void beans() {
		assertNotNull(questionRepository);
		
		log.info("┌───────────────────────────┐");
		log.info("│ *beans()*                 │");
		log.info("└───────────────────────────┘");
		
		
		log.info("questionRepository:{}",questionRepository);
		
		
	}

}
