package com.pcwk.ehr;

import java.sql.Connection;
import java.sql.DriverManager;

public class OracleConnectionTest {

    public static void main(String[] args) throws Exception {
        Class.forName("oracle.jdbc.OracleDriver");
        Connection conn = DriverManager.getConnection(
            "jdbc:oracle:thin:@192.168.100.30:1522:XE", "scott", "pcwk"
        );
        System.out.println("Connection success: " + !conn.isClosed());
        conn.close();
    }

}
